import React, { useState } from 'react';
import {
  Crown,
  ShieldCheck,
  User,
  Settings,
  Activity,
  Shield,
  ChevronRight,
  Sparkles,
  ShoppingBag,
  Headphones,
  Smartphone,
  ExternalLink,
  Flame,
  CheckCircle2,
  Users,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface DashboardPageProps {
  onNavigate: (page: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const { currentUser } = useAuth();
  const [activeModal, setActiveModal] = useState<'status' | 'role' | 'drk-info' | null>(null);

  return (
    <div className="p-4 space-y-4 max-w-md mx-auto pb-24 select-none">
      {/* User Welcome Card - Matching screenshot IMG_20261017_210305_200.jpg */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-slate-900/95 via-slate-900/90 to-[#0c1424] border border-slate-700/80 shadow-[0_4px_25px_rgba(0,0,0,0.6)] backdrop-blur-md relative overflow-hidden">
        {/* Glow corner */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-start gap-3.5">
          {/* Avatar with cyan neon border */}
          <div
            onClick={() => onNavigate('profile')}
            className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-sky-400/80 glow-blue shadow-lg bg-black relative shrink-0 cursor-pointer group"
          >
            <img
              src={currentUser?.avatarUrl || '/drk_avatar.jpg'}
              alt={currentUser?.displayName}
              className="w-full h-full object-cover group-hover:scale-105 transition"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end justify-center pb-0.5">
              <span className="text-[8px] font-black text-sky-300 tracking-wider">
                DRK XXVII
              </span>
            </div>
          </div>

          {/* User info */}
          <div className="flex-1 min-w-0">
            <span className="text-[11px] text-slate-400 font-medium tracking-tight">
              Welcome back,
            </span>
            <h1 className="text-lg font-black text-white truncate tracking-wide font-display mt-0.5">
              {currentUser?.displayName || 'ANSEN ANTONIO'}
            </h1>

            {/* Badges row */}
            <div className="flex flex-wrap items-center gap-1.5 mt-2">
              {/* Role badge */}
              <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-400/50 text-[10px] font-extrabold tracking-wider uppercase">
                <Crown className="w-3 h-3 text-sky-400" />
                <span>{currentUser?.role || 'DEVELOPER'}</span>
              </div>

              {/* Status badge */}
              <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/50 text-[10px] font-extrabold tracking-wider uppercase">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                <span>{currentUser?.status || 'PERMANEN'}</span>
              </div>

              {/* Tag badge */}
              <div className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 text-[10px] font-bold">
                DRK XXVII
              </div>
            </div>
          </div>
        </div>

        {/* User ID and Quick Button */}
        <div className="mt-4 pt-3.5 border-t border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-400 text-xs">
            <div className="p-1 rounded bg-slate-800/80 text-slate-300">
              <User className="w-3.5 h-3.5" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block -mb-0.5">ID User</span>
              <span className="text-xs font-mono font-bold text-slate-200">
                {currentUser?.id || 'DRK-2026-001'}
              </span>
            </div>
          </div>

          <button
            onClick={() => setActiveModal('drk-info')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-500/15 hover:bg-sky-500/25 border border-sky-400/40 text-sky-300 text-xs font-bold transition active:scale-95"
          >
            <Crown className="w-3.5 h-3.5 text-sky-400" />
            <span>DRK XXVII</span>
            <ChevronRight className="w-3.5 h-3.5 text-sky-400" />
          </button>
        </div>
      </div>

      {/* Menu KELOLA AKUN Quick Access Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-[#0e1628] border border-amber-500/40 shadow-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="text-xs font-black text-white uppercase tracking-wider">
                Kelola Akun
              </h3>
              <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Otoritas
              </span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">
              Buat akun, atur role, & kelola masa aktif
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigate('kelola-akun')}
          className="px-3 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 text-xs font-bold transition flex items-center gap-1 active:scale-95 shrink-0"
        >
          <span>Buka Menu</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 4 Action Cards Grid - Matching screenshot IMG_20261017_210305_200.jpg */}
      <div className="grid grid-cols-2 gap-3">
        {/* Card 1: Profil */}
        <button
          onClick={() => onNavigate('profile')}
          className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 hover:border-sky-500/50 transition text-left flex flex-col justify-between group active:scale-[0.98]"
        >
          <div className="flex items-center justify-between w-full">
            <div className="w-9 h-9 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400 group-hover:scale-105 transition">
              <User className="w-4 h-4" />
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-sky-400 transition" />
          </div>
          <div className="mt-3">
            <h3 className="text-sm font-bold text-white group-hover:text-sky-300 transition">
              Profil
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
              Lihat dan atur profil akun kamu
            </p>
          </div>
        </button>

        {/* Card 2: Akun */}
        <button
          onClick={() => onNavigate('pengaturan')}
          className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 hover:border-sky-500/50 transition text-left flex flex-col justify-between group active:scale-[0.98]"
        >
          <div className="flex items-center justify-between w-full">
            <div className="w-9 h-9 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400 group-hover:scale-105 transition">
              <Settings className="w-4 h-4" />
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-sky-400 transition" />
          </div>
          <div className="mt-3">
            <h3 className="text-sm font-bold text-white group-hover:text-sky-300 transition">
              Akun
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
              Kelola akun dan keamanan
            </p>
          </div>
        </button>

        {/* Card 3: Status */}
        <button
          onClick={() => setActiveModal('status')}
          className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 hover:border-emerald-500/50 transition text-left flex flex-col justify-between group active:scale-[0.98]"
        >
          <div className="flex items-center justify-between w-full">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition">
              <Activity className="w-4 h-4" />
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 transition" />
          </div>
          <div className="mt-3">
            <h3 className="text-sm font-bold text-white group-hover:text-emerald-300 transition">
              Status
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
              Aktif dan terverifikasi
            </p>
          </div>
        </button>

        {/* Card 4: Role */}
        <button
          onClick={() => setActiveModal('role')}
          className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 hover:border-red-500/50 transition text-left flex flex-col justify-between group active:scale-[0.98]"
        >
          <div className="flex items-center justify-between w-full">
            <div className="w-9 h-9 rounded-xl bg-red-500/15 border border-red-500/30 flex items-center justify-center text-red-400 group-hover:scale-105 transition">
              <Shield className="w-4 h-4" />
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-red-400 transition" />
          </div>
          <div className="mt-3">
            <h3 className="text-sm font-bold text-white group-hover:text-red-300 transition">
              Role
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
              {currentUser?.role === 'DEVELOPER'
                ? 'Developer (Permanen)'
                : `${currentUser?.role || 'Member'} (${currentUser?.status || 'Aktif'})`}
            </p>
          </div>
        </button>
      </div>

      {/* Featured Purchase CTA Banner (Direct button to Beli Sekarang without showing open contact details on home!) */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-red-950/70 via-slate-900 to-black border border-red-800/60 shadow-lg flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-red-400 text-xs font-bold uppercase tracking-wider">
            <Flame className="w-4 h-4" />
            <span>Menu Layanan & Lisensi</span>
          </div>
          <h3 className="text-sm font-extrabold text-white">
            Pemesanan Sistem DRK XXVII
          </h3>
          <p className="text-[11px] text-slate-300">
            Akses lisensi dan dedicated suite
          </p>
        </div>

        <button
          onClick={() => onNavigate('pembelian')}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white text-xs font-black tracking-wider uppercase shadow-[0_0_15px_rgba(220,38,38,0.5)] border border-red-400/40 active:scale-95 transition shrink-0"
        >
          Beli Sekarang
        </button>
      </div>

      {/* Discrete Contact Menu Button (As required: no names/handles displayed on home!) */}
      <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400">
            <Headphones className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">Pusat Kontak Layanan</h4>
            <p className="text-[10px] text-slate-400">
              Tekan untuk membuka informasi kontak resmi
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigate('kontak')}
          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold text-slate-200 transition"
        >
          Buka Kontak
        </button>
      </div>

      {/* Latest Updates Section - Matching screenshot IMG_20261017_210305_200.jpg */}
      <div className="space-y-2.5 pt-1">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-4 bg-sky-500 rounded-full"></span>
            <h2 className="text-base font-extrabold text-white">
              Latest Updates
            </h2>
          </div>
          <span className="text-[11px] text-slate-400 font-medium">2 articles</span>
        </div>

        {/* Update Card 1 */}
        <div className="rounded-2xl overflow-hidden border border-slate-800 bg-slate-900 shadow-xl relative">
          <div className="h-44 w-full overflow-hidden relative">
            <img
              src="/drk_banner_duo.jpg"
              alt="DRK XXVII Update"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-black/30" />

            <div className="absolute top-3 left-3">
              <span className="px-2.5 py-1 rounded-lg bg-sky-500 text-white text-[10px] font-black tracking-wider uppercase shadow">
                UPDATE
              </span>
            </div>

            <div className="absolute top-3 right-3">
              <span className="px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-[10px] font-mono text-slate-200 border border-slate-700">
                1/2
              </span>
            </div>

            <div className="absolute bottom-3 left-3 right-3">
              <h3 className="text-base font-black text-white font-display tracking-wide drop-shadow">
                DRK XXVII — STRONGER • SAFER • TOGETHER
              </h3>
              <p className="text-[11px] text-slate-300 mt-0.5">
                Pembaruan performa keamanan arsitektur dan sistem modular.
              </p>
            </div>
          </div>
        </div>

        {/* Update Card 2 */}
        <div className="rounded-2xl overflow-hidden border border-slate-800 bg-slate-900 shadow-xl relative">
          <div className="h-40 w-full overflow-hidden relative">
            <img
              src="/drk_warrior.jpg"
              alt="DRK Engine"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-black/30" />

            <div className="absolute top-3 left-3">
              <span className="px-2.5 py-1 rounded-lg bg-red-600 text-white text-[10px] font-black tracking-wider uppercase shadow">
                ENGINE V2.7
              </span>
            </div>

            <div className="absolute top-3 right-3">
              <span className="px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-[10px] font-mono text-slate-200 border border-slate-700">
                2/2
              </span>
            </div>

            <div className="absolute bottom-3 left-3 right-3">
              <h3 className="text-sm font-black text-white font-display tracking-wide">
                Optimalisasi WhatsApp Module & Dedicated Sender
              </h3>
              <p className="text-[10px] text-slate-300 mt-0.5">
                Stabilitas payload terproteksi dengan kontrol penuh pada aplikasi Android.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Modals for Status & Role details */}
      {activeModal === 'status' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2 text-emerald-400">
                <Activity className="w-5 h-5" />
                <h3 className="text-base font-bold text-white">Status Akun</h3>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Kondisi Akun</span>
                <span className="font-bold text-emerald-400">Aktif & Terverifikasi</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Durasi Status</span>
                <span className="font-bold text-sky-400">{currentUser?.status || 'PERMANEN'}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">ID Pengguna</span>
                <span className="font-mono text-slate-200">{currentUser?.id}</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Akun Anda telah tervalidasi dalam protokol keamanan DRK XXVII dan memiliki status aktif tanpa batasan kedaluwarsa.
            </p>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold"
            >
              Tutup
            </button>
          </div>
        </div>
      )}

      {activeModal === 'role' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2 text-sky-400">
                <Crown className="w-5 h-5" />
                <h3 className="text-base font-bold text-white">Hak Akses Role</h3>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Tingkat Hak Akses</span>
                <span className="font-bold text-sky-400">{currentUser?.role}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Status Otorisasi</span>
                <span className="font-bold text-emerald-400">Telah Diberikan Resmi</span>
              </div>
            </div>

            <div className="text-xs text-slate-300 space-y-1.5">
              <p className="font-semibold text-slate-200">Hak Akses Tersedia:</p>
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Akses penuh konfigurasi arsitektur sistem</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Penggunaan modul pengiriman & tools lanjutan</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Akses prioritas pesanan & dukungan Telegram</span>
              </div>
            </div>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold"
            >
              Tutup
            </button>
          </div>
        </div>
      )}

      {activeModal === 'drk-info' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2 text-white">
                <Crown className="w-5 h-5 text-sky-400" />
                <h3 className="text-base font-bold">DRK XXVII Official</h3>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              DRK XXVII adalah platform dan sistem aplikasi digital serbaguna yang dirancang dengan keamanan terstandarisasi, tampilan modern, dan ekosistem terpadu.
            </p>

            <div className="p-3 rounded-xl bg-black/60 border border-slate-800 text-center">
              <span className="text-xs font-mono text-sky-400 tracking-wider">
                STRONGER • SAFER • TOGETHER
              </span>
            </div>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold"
            >
              Kembali ke Beranda
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
