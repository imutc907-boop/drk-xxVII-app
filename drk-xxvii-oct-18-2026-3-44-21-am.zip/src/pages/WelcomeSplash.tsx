import React, { useState } from 'react';
import { ArrowRight, Shield, Award, Terminal, ChevronRight, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface WelcomeSplashProps {
  onEnterApp: () => void;
  onGoToLogin: () => void;
  onQuickDevLogin: () => void;
}

export const WelcomeSplash: React.FC<WelcomeSplashProps> = ({
  onEnterApp,
  onGoToLogin,
  onQuickDevLogin
}) => {
  const [step, setStep] = useState<1 | 2>(1);

  if (step === 1) {
    return (
      <div className="relative min-h-screen flex flex-col justify-between p-6 bg-black text-white overflow-hidden max-w-md mx-auto select-none">
        {/* Background Image matching user's splash screenshot */}
        <div className="absolute inset-0 z-0">
          <img
            src="/drk_splash.jpg"
            alt="DRK XXVII Hero"
            className="w-full h-full object-cover object-center opacity-85 brightness-95"
          />
          {/* Subtle gradient overlays */}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black" />
        </div>

        {/* Top spacer */}
        <div className="relative z-10 pt-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping"></span>
            <span className="text-xs uppercase tracking-widest text-slate-300 font-semibold font-display">
              Official Release
            </span>
          </div>
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-black/60 backdrop-blur-md border border-slate-700/60 text-slate-300">
            DRK-2026
          </span>
        </div>

        {/* Center content */}
        <div className="relative z-10 flex flex-col items-center text-center mt-auto pb-4">
          {/* Glowing Crown Icon */}
          <div className="mb-2 text-sky-400 drop-shadow-[0_0_12px_rgba(56,189,248,0.8)]">
            <svg className="w-7 h-7 mx-auto fill-current" viewBox="0 0 24 24">
              <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5m14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z"/>
            </svg>
          </div>

          <h1 className="text-4xl sm:text-5xl font-black tracking-wider text-white font-display drop-shadow-[0_4px_16px_rgba(0,0,0,0.9)]">
            DRK <span className="silver-gradient-text">XXVII</span>
          </h1>

          <p className="text-[11px] sm:text-xs font-bold tracking-[0.3em] text-slate-300 mt-1 uppercase">
            Stronger • Safer • Together
          </p>

          <div className="w-12 h-0.5 bg-gradient-to-r from-sky-400 via-white to-red-500 rounded-full my-4"></div>

          <h2 className="text-sm sm:text-base font-bold text-slate-100">
            Selamat datang di DRK XXVII
          </h2>
          <p className="text-xs text-slate-300 max-w-xs mt-1.5 leading-relaxed">
            Aplikasi serbaguna untuk kebutuhan digitalmu, dalam satu genggaman.
          </p>

          {/* Dots Indicator */}
          <div className="flex items-center gap-1.5 my-5">
            <span className="w-6 h-1.5 rounded-full bg-sky-400"></span>
            <span className="w-1.5 h-1.5 rounded-full bg-slate-600"></span>
            <span className="w-1.5 h-1.5 rounded-full bg-slate-600"></span>
          </div>

          {/* Button LANJUT */}
          <button
            onClick={() => setStep(2)}
            className="w-full max-w-xs py-3.5 px-6 rounded-full bg-transparent hover:bg-sky-500/20 active:bg-sky-500/30 border-2 border-sky-400 text-sky-300 hover:text-white font-bold flex items-center justify-center gap-3 shadow-[0_0_20px_rgba(56,189,248,0.4)] transition"
          >
            <ArrowRight className="w-5 h-5 text-sky-400" />
            <span className="tracking-widest font-extrabold uppercase text-sm">Lanjut</span>
          </button>
        </div>
      </div>
    );
  }

  // Step 2: About screen matching IMG_20261017_210304_739.jpg
  return (
    <div className="relative min-h-screen flex flex-col justify-between p-5 bg-[#070b14] text-white overflow-hidden max-w-md mx-auto select-none">
      {/* Top Banner with Duo Art */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-800 shadow-2xl h-56">
        <img
          src="/drk_banner_duo.jpg"
          alt="DRK XXVII Banner"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#070b14] via-transparent to-black/30" />
        <div className="absolute bottom-3 left-4">
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-600/80 text-white tracking-widest uppercase">
            Official System
          </span>
          <h2 className="text-2xl font-black font-display text-white mt-1">
            DRK XXVII
          </h2>
          <p className="text-[11px] text-slate-300">
            Aplikasi yang dikembangkan oleh DRK XXVII Team
          </p>
        </div>
      </div>

      {/* Info Card */}
      <div className="my-5 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl backdrop-blur-md">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-8 h-8 rounded-full bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-sky-400">
            <span className="font-bold text-sm">i</span>
          </div>
          <h3 className="text-base font-extrabold text-white">
            Tentang DRK XXVII
          </h3>
        </div>

        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
          DRK XXVII dirancang dengan tampilan modern, fitur yang tertata, dan pengalaman penggunaan yang nyaman.
        </p>

        <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-red-500" />
            <span>Enkripsi Aman</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            <span>Respon Cepat</span>
          </div>
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="space-y-3 pb-4">
        {/* Sign In Button */}
        <button
          onClick={onGoToLogin}
          className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-extrabold flex items-center justify-between shadow-[0_4px_20px_rgba(2,132,199,0.4)] border border-sky-400/40 transition active:scale-[0.98]"
        >
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-sky-200" />
            <span className="text-sm tracking-wide">Sign-in to DRK XXVII</span>
          </div>
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* Secondary Buttons: Developer & Creator */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={onQuickDevLogin}
            className="py-3 px-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-800 hover:border-sky-500/50 flex items-center justify-between text-xs font-bold transition"
          >
            <span>Developer</span>
            <ChevronRight className="w-4 h-4 text-sky-400" />
          </button>

          <button
            onClick={onEnterApp}
            className="py-3 px-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-800 hover:border-red-500/50 flex items-center justify-between text-xs font-bold transition"
          >
            <span>Creator</span>
            <ChevronRight className="w-4 h-4 text-red-400" />
          </button>
        </div>

        <p className="text-center text-[10px] text-slate-500 pt-1">
          © 2026 DRK XXVII — Hak Cipta Dilindungi
        </p>
      </div>
    </div>
  );
};
