import React, { useState } from 'react';
import {
  Crown,
  UserCheck,
  Send,
  ExternalLink,
  Copy,
  Check,
  Shield,
  Headphones,
  Sparkles,
  ArrowLeft
} from 'lucide-react';

interface KontakPageProps {
  onBack: () => void;
}

export const KontakPage: React.FC<KontakPageProps> = ({ onBack }) => {
  const [copiedHandle, setCopiedHandle] = useState<string | null>(null);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedHandle(text);
    setTimeout(() => {
      setCopiedHandle(null);
    }, 2000);
  };

  const handleOpenTelegram = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="p-4 space-y-4 max-w-md mx-auto pb-24 select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-1">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition py-1"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali</span>
        </button>

        <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400">
          DRK XXVII Official
        </span>
      </div>

      {/* Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-[#0c1424] border border-slate-700 shadow-xl space-y-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-sky-400">
            <Headphones className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-lg font-black text-white font-display">
              Pusat Kontak Resmi
            </h1>
            <p className="text-[11px] text-slate-400">
              Jalur komunikasi langsung dengan Pemilik dan Admin
            </p>
          </div>
        </div>
      </div>

      {/* SECTION 1: PEMILIK (ANSEN ANTONIO — @AZXV71) */}
      <div className="p-5 rounded-2xl bg-slate-900/95 border-2 border-red-600/60 shadow-[0_4px_25px_rgba(220,38,38,0.25)] space-y-4 relative overflow-hidden">
        {/* Glow corner */}
        <div className="absolute top-0 right-0 w-28 h-28 bg-red-600/10 rounded-full blur-xl pointer-events-none" />

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-red-600 text-white shadow">
              BAGIAN PEMILIK
            </span>
            <span className="text-[10px] text-red-400 font-bold uppercase">
              Otoritas Tertinggi
            </span>
          </div>
          <Crown className="w-5 h-5 text-red-400" />
        </div>

        <div className="flex items-start gap-3.5 pt-1">
          <div className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-red-500/80 glow-red bg-black shrink-0">
            <img src="/drk_avatar.jpg" alt="ANSEN ANTONIO" className="w-full h-full object-cover" />
          </div>

          <div className="space-y-0.5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider">
              Pemilik & Developer Utama
            </span>
            <h2 className="text-lg font-black text-white tracking-wide font-display">
              ANSEN ANTONIO
            </h2>
            <div className="flex items-center gap-1.5 text-xs text-red-400 font-mono font-bold">
              <span>@AZXV71</span>
              <button
                onClick={() => copyToClipboard('@AZXV71')}
                className="p-1 hover:text-white transition"
                title="Salin username Telegram"
              >
                {copiedHandle === '@AZXV71' ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed pt-1">
          Hubungi pemilik untuk konsultasi arsitektur, lisensi tingkat lanjut, integrasi server khusus, atau otorisasi hak akses permanen.
        </p>

        {/* Buttons for Owner */}
        <div className="pt-1 flex flex-col gap-2">
          <button
            onClick={() => handleOpenTelegram('https://t.me/AZXV71')}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-extrabold text-xs tracking-wider uppercase shadow-[0_0_15px_rgba(220,38,38,0.4)] border border-red-400/40 active:scale-95 transition flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>Buka Telegram Pemilik (@AZXV71)</span>
          </button>

          <button
            onClick={() => handleOpenTelegram('https://t.me/AZXV71')}
            className="w-full py-2 px-3 rounded-lg bg-slate-950/80 hover:bg-slate-800 border border-slate-800 text-[11px] text-slate-300 flex items-center justify-center gap-1.5 transition"
          >
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            <span>Buka melalui Browser Web (https://t.me/AZXV71)</span>
          </button>
        </div>
      </div>

      {/* SECTION 2: ADMIN (@Danzxwoilah) */}
      <div className="p-5 rounded-2xl bg-slate-900/95 border-2 border-sky-500/60 shadow-[0_4px_25px_rgba(14,165,233,0.2)] space-y-4 relative overflow-hidden">
        {/* Glow corner */}
        <div className="absolute top-0 right-0 w-28 h-28 bg-sky-500/10 rounded-full blur-xl pointer-events-none" />

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-sky-600 text-white shadow">
              BAGIAN ADMIN
            </span>
            <span className="text-[10px] text-sky-400 font-bold uppercase">
              Layanan & Operasional
            </span>
          </div>
          <UserCheck className="w-5 h-5 text-sky-400" />
        </div>

        <div className="flex items-start gap-3.5 pt-1">
          <div className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-sky-400/80 glow-blue bg-black shrink-0 flex items-center justify-center">
            <UserCheck className="w-7 h-7 text-sky-400" />
          </div>

          <div className="space-y-0.5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider">
              Administrator Sistem
            </span>
            <h2 className="text-lg font-black text-white tracking-wide font-display">
              ADMIN DRK XXVII
            </h2>
            <div className="flex items-center gap-1.5 text-xs text-sky-400 font-mono font-bold">
              <span>@Danzxwoilah</span>
              <button
                onClick={() => copyToClipboard('@Danzxwoilah')}
                className="p-1 hover:text-white transition"
                title="Salin username Telegram"
              >
                {copiedHandle === '@Danzxwoilah' ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed pt-1">
          Hubungi admin untuk proses verifikasi pesanan, kendala operasional, bantuan akun anggota, atau pertanyaan umum seputar DRK XXVII.
        </p>

        {/* Buttons for Admin */}
        <div className="pt-1 flex flex-col gap-2">
          <button
            onClick={() => handleOpenTelegram('https://t.me/Danzxwoilah')}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-extrabold text-xs tracking-wider uppercase shadow-[0_0_15px_rgba(2,132,199,0.4)] border border-sky-400/40 active:scale-95 transition flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>Buka Telegram Admin (@Danzxwoilah)</span>
          </button>

          <button
            onClick={() => handleOpenTelegram('https://t.me/Danzxwoilah')}
            className="w-full py-2 px-3 rounded-lg bg-slate-950/80 hover:bg-slate-800 border border-slate-800 text-[11px] text-slate-300 flex items-center justify-center gap-1.5 transition"
          >
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            <span>Buka melalui Browser Web (https://t.me/Danzxwoilah)</span>
          </button>
        </div>
      </div>

      {/* Safety Notice */}
      <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 flex items-start gap-2.5">
        <Shield className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          Pastikan Anda hanya bertransaksi dan berkomunikasi melalui kontak resmi yang tercantum di atas untuk menjamin keaslian dan keamanan akun Anda.
        </p>
      </div>
    </div>
  );
};
