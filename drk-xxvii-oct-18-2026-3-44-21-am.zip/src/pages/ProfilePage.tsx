import React, { useRef, useState } from 'react';
import {
  User,
  Camera,
  Crown,
  ShieldCheck,
  Check,
  Save,
  KeyRound,
  Calendar,
  Sparkles,
  Smartphone,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface ProfilePageProps {
  onNavigateToSettings: () => void;
  onNavigateToApk: () => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({
  onNavigateToSettings,
  onNavigateToApk
}) => {
  const { currentUser, updateProfilePhoto, updateProfileDetails } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [displayName, setDisplayName] = useState(currentUser?.displayName || 'ANSEN ANTONIO');
  const [bio, setBio] = useState(currentUser?.bio || 'Lead Developer & Architect DRK XXVII Systems');
  const [savedToast, setSavedToast] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit: 5MB
    if (file.size > 5 * 1024 * 1024) {
      alert('Ukuran file maksimal 5MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        updateProfilePhoto(result);
        setSavedToast(true);
        setTimeout(() => setSavedToast(false), 2500);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveDetails = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileDetails(displayName, bio);
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 2500);
  };

  return (
    <div className="p-4 space-y-4 max-w-md mx-auto pb-24 select-none">
      {/* Hidden file input for Android Gallery upload */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* Main Profile Card */}
      <div className="p-6 rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-[#0a101d] border border-slate-700/80 shadow-2xl relative overflow-hidden text-center">
        {/* Glow corner */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-40 bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Profile Avatar with Gallery Tap */}
        <div className="relative inline-block mx-auto mb-3">
          <div className="w-24 h-24 rounded-3xl overflow-hidden border-2 border-sky-400/80 glow-blue shadow-xl bg-black relative">
            <img
              src={currentUser?.avatarUrl || '/drk_avatar.jpg'}
              alt={currentUser?.displayName}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Camera Button for Android Gallery */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="absolute -bottom-1 -right-1 p-2 rounded-2xl bg-red-600 hover:bg-red-500 text-white shadow-lg border-2 border-black active:scale-95 transition"
            title="Ganti foto dari galeri HP"
          >
            <Camera className="w-4 h-4" />
          </button>
        </div>

        <button
          onClick={() => fileInputRef.current?.click()}
          className="text-xs text-sky-400 hover:text-sky-300 font-bold block mb-3"
        >
          Ganti Foto dari Galeri HP &rarr;
        </button>

        <h1 className="text-xl font-black text-white font-display tracking-wide">
          {currentUser?.displayName || 'ANSEN ANTONIO'}
        </h1>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          @{currentUser?.username || 'ansenantonio'}
        </p>

        {/* Badges */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-3">
          <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 border border-sky-400/50 text-xs font-black uppercase tracking-wider">
            <Crown className="w-3.5 h-3.5 text-sky-400" />
            <span>{currentUser?.role || 'DEVELOPER'}</span>
          </div>

          <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/50 text-xs font-black uppercase tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>{currentUser?.status || 'PERMANEN'}</span>
          </div>
        </div>

        {/* User Details Grid */}
        <div className="grid grid-cols-2 gap-2 mt-5 pt-4 border-t border-slate-800 text-left">
          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 block">ID Pengguna</span>
            <span className="text-xs font-mono font-bold text-slate-200">
              {currentUser?.id || 'DRK-2026-001'}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 block">Terdaftar Sejak</span>
            <span className="text-xs font-bold text-slate-200">
              {currentUser?.createdAt || '2026-01-01'}
            </span>
          </div>
        </div>
      </div>

      {/* Edit Profile Form */}
      <form onSubmit={handleSaveDetails} className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
        <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-300 flex items-center gap-2">
          <span className="w-1.5 h-3.5 bg-red-500 rounded-full"></span>
          <span>Pengaturan Biodata Profil</span>
        </h3>

        <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-400">
            Nama Lengkap yang Ditampilkan
          </label>
          <input
            type="text"
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:border-sky-500 outline-none"
          />
        </div>

        <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-400">
            Biodata Akun
          </label>
          <textarea
            rows={3}
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:border-sky-500 outline-none resize-none"
          />
        </div>

        <button
          type="submit"
          className="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-bold text-xs uppercase tracking-wider shadow-lg active:scale-95 transition flex items-center justify-center gap-2"
        >
          <Save className="w-4 h-4" />
          <span>Simpan Perubahan Profil</span>
        </button>
      </form>

      {/* Quick Navigation Cards */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={onNavigateToSettings}
          className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 text-left space-y-1 transition"
        >
          <KeyRound className="w-4 h-4 text-sky-400" />
          <div className="text-xs font-bold text-white">Otorisasi Role</div>
          <div className="text-[10px] text-slate-400">Ubah hak akses khusus</div>
        </button>

        <button
          onClick={onNavigateToApk}
          className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 text-left space-y-1 transition"
        >
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <div className="text-xs font-bold text-white">APK Android</div>
          <div className="text-[10px] text-slate-400">Status build & install</div>
        </button>
      </div>

      {/* Saved Toast */}
      {savedToast && (
        <div className="fixed bottom-20 left-4 right-4 max-w-sm mx-auto z-50 p-3 rounded-xl bg-emerald-600 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-2xl animate-fade-in">
          <Check className="w-4 h-4" />
          <span>Profil berhasil diperbarui dan disimpan!</span>
        </div>
      )}
    </div>
  );
};
