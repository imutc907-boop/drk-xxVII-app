import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Search,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Crown,
  KeyRound,
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Lock,
  Eye,
  EyeOff,
  Trash2,
  Power,
  Edit3,
  Copy,
  Check,
  Sparkles,
  ArrowLeft,
  X,
  Server,
  RefreshCw
} from 'lucide-react';
import { useAuth, formatDateTime } from '../context/AuthContext';
import { User, UserRole, ValidityDuration, CreatedAccountSummary } from '../types';

interface KelolaAkunPageProps {
  onBack: () => void;
}

export const KelolaAkunPage: React.FC<KelolaAkunPageProps> = ({ onBack }) => {
  const {
    currentUser,
    allUsers,
    isServerConnected,
    createAccount,
    updateAccount,
    toggleAccountActive,
    deleteAccount,
    refreshAccounts,
    checkPermission
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'DAFTAR' | 'BUAT_AKUN'>('DAFTAR');

  // Form State for BUAT AKUN
  const [formUsername, setFormUsername] = useState('');
  const [formDisplayName, setFormDisplayName] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formConfirmPassword, setFormConfirmPassword] = useState('');
  const [formRole, setFormRole] = useState<UserRole>('MEMBER');
  const [formValidity, setFormValidity] = useState<ValidityDuration>('1 BULAN');
  const [showPassword, setShowPassword] = useState(false);
  const [formError, setFormError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Success summary modal
  const [createdSummary, setCreatedSummary] = useState<CreatedAccountSummary | null>(null);
  const [copiedSummary, setCopiedSummary] = useState(false);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'ALL' | UserRole>('ALL');

  // Edit Modal State
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editDisplayName, setEditDisplayName] = useState('');
  const [editValidity, setEditValidity] = useState<ValidityDuration>('1 BULAN');
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  // Permission Check for opening KELOLA AKUN
  const isAuthorizedToManage =
    currentUser && (currentUser.role === 'ADMIN' || currentUser.role === 'OWNER' || currentUser.role === 'DEVELOPER');

  if (!isAuthorizedToManage) {
    return (
      <div className="p-4 space-y-4 max-w-md mx-auto pb-24 select-none">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition py-1"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Beranda</span>
        </button>

        <div className="p-6 rounded-3xl bg-slate-900/90 border-2 border-red-600/60 shadow-2xl text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-red-600/20 border border-red-500/50 flex items-center justify-center mx-auto text-red-400 glow-red">
            <ShieldAlert className="w-8 h-8" />
          </div>

          <div>
            <span className="px-2.5 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-red-600/30 text-red-400 border border-red-500/40">
              AKSES DITOLAK
            </span>
            <h1 className="text-xl font-black text-white font-display mt-2">
              Menu KELOLA AKUN Terproteksi
            </h1>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              Menu ini hanya dapat dibuka oleh pengguna dengan izin resmi <strong>ADMIN</strong>, <strong>OWNER</strong>, atau <strong>DEVELOPER</strong>.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-left space-y-1.5 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Akun Anda:</span>
              <span className="font-bold text-white">{currentUser?.displayName || 'Tamu'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Role Saat Ini:</span>
              <span className="font-bold text-red-400">{currentUser?.role || 'MEMBER'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Status Otorisasi:</span>
              <span className="text-amber-400 font-bold">Tidak Memiliki Izin Kelola</span>
            </div>
          </div>

          <p className="text-[11px] text-slate-400">
            Hubungi pengembang atau administrator sistem untuk otorisasi hak akses khusus.
          </p>

          <button
            onClick={onBack}
            className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition"
          >
            Kembali ke Menu Utama
          </button>
        </div>
      </div>
    );
  }

  // Handle Form Submission for BUAT AKUN
  const handleCreateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (formPassword !== formConfirmPassword) {
      setFormError('Konfirmasi password tidak cocok dengan password yang dimasukkan.');
      return;
    }

    if (formPassword.length < 4) {
      setFormError('Password minimal 4 karakter.');
      return;
    }

    setIsSubmitting(true);
    const result = await createAccount({
      username: formUsername,
      password: formPassword,
      confirmPassword: formConfirmPassword,
      role: formRole,
      validity: formValidity,
      displayName: formDisplayName || formUsername
    });

    setIsSubmitting(false);

    if (result.success && result.account) {
      setCreatedSummary(result.account);
      // Reset form
      setFormUsername('');
      setFormDisplayName('');
      setFormPassword('');
      setFormConfirmPassword('');
      setFormRole('MEMBER');
      setFormValidity('1 BULAN');
    } else {
      setFormError(result.message || 'Gagal membuat akun.');
    }
  };

  // Handle Edit Account Submission
  const handleSaveEdit = async () => {
    if (!editingUser) return;
    setIsSavingEdit(true);
    await updateAccount(editingUser.id, {
      displayName: editDisplayName,
      validity: editValidity
    });
    setIsSavingEdit(false);
    setEditingUser(null);
  };

  // Filter accounts
  const filteredUsers = allUsers.filter((u) => {
    const matchesSearch =
      u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.role.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRole = roleFilter === 'ALL' || u.role === roleFilter;

    return matchesSearch && matchesRole;
  });

  const copyCreatedSummaryText = () => {
    if (!createdSummary) return;
    const text = `=== DRK XXVII — INFORMASI AKUN BARU ===\nUsername: ${createdSummary.username}\nRole: ${createdSummary.role}\nTanggal Dibuat: ${createdSummary.createdAt}\nMasa Aktif: ${createdSummary.validity}\nTanggal Kedaluwarsa: ${createdSummary.expiresAt}\n======================================`;
    navigator.clipboard.writeText(text);
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 2500);
  };

  return (
    <div className="p-4 space-y-4 max-w-md mx-auto pb-28 select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-1">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition py-1"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali</span>
        </button>

        <div className="flex items-center gap-2">
          <div
            className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono border ${
              isServerConnected
                ? 'bg-emerald-950/60 border-emerald-600/50 text-emerald-400'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
            title="Status Sinkronisasi Backend Server"
          >
            <Server className="w-3 h-3" />
            <span>{isServerConnected ? 'Server Backend Aktif' : 'Penyimpanan Lokal'}</span>
          </div>

          <button
            onClick={() => refreshAccounts()}
            className="p-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            title="Segarkan Data"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-red-950/90 via-slate-900 to-[#070b14] border border-red-700/60 shadow-xl space-y-2 relative overflow-hidden">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-red-600 text-white shadow">
              MANAJEMEN OTORISASI
            </span>
            <span className="text-xs font-mono text-red-400 font-bold">DRK XXVII</span>
          </div>
          <Crown className="w-5 h-5 text-red-400" />
        </div>

        <h1 className="text-xl font-black text-white font-display">
          Kelola Akun & Hak Akses
        </h1>
        <p className="text-xs text-slate-300 leading-relaxed">
          Pusat kontrol resmi pembuatan akun, pengaturan role sensitif, pemantauan masa aktif, dan status kedaluwarsa.
        </p>

        <div className="pt-2 flex items-center gap-2 text-[11px] text-slate-400">
          <span>Otoritas Anda:</span>
          <span className="px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-400/40 font-bold uppercase">
            {currentUser?.role}
          </span>
        </div>
      </div>

      {/* Tabs Switcher: DAFTAR AKUN vs BUAT AKUN */}
      <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-slate-900/90 border border-slate-800">
        <button
          onClick={() => setActiveTab('DAFTAR')}
          className={`py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
            activeTab === 'DAFTAR'
              ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Daftar Akun ({allUsers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('BUAT_AKUN')}
          className={`py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
            activeTab === 'BUAT_AKUN'
              ? 'bg-gradient-to-r from-red-600 to-red-700 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <UserPlus className="w-4 h-4" />
          <span>Formulir Buat Akun</span>
        </button>
      </div>

      {/* TAB 1: FORMULIR BUAT AKUN */}
      {activeTab === 'BUAT_AKUN' && (
        <form onSubmit={handleCreateAccount} className="p-5 rounded-2xl bg-slate-900/95 border border-slate-800 space-y-4 shadow-2xl">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2 text-white">
              <UserPlus className="w-4 h-4 text-red-400" />
              <h2 className="text-sm font-extrabold uppercase tracking-wide">
                Formulir Buat Akun Baru
              </h2>
            </div>
            <span className="text-[10px] font-mono text-slate-400">DRK XXVII</span>
          </div>

          {formError && (
            <div className="p-3 rounded-xl bg-red-950/80 border border-red-800 text-red-300 text-xs flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
              <span>{formError}</span>
            </div>
          )}

          {/* 1. Username */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300 block">
              Username <span className="text-red-400">*</span>
            </label>
            <input
              type="text"
              required
              value={formUsername}
              onChange={(e) => setFormUsername(e.target.value)}
              placeholder="Contoh: user_drk01"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs placeholder-slate-500 focus:border-red-500 outline-none"
            />
          </div>

          {/* Optional Display Name */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-400 block">
              Nama Lengkap / Tampilan (Opsional)
            </label>
            <input
              type="text"
              value={formDisplayName}
              onChange={(e) => setFormDisplayName(e.target.value)}
              placeholder="Nama pemilik akun"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs placeholder-slate-500 focus:border-red-500 outline-none"
            />
          </div>

          {/* 2. Password */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300 block">
              Password <span className="text-red-400">*</span>
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={formPassword}
                onChange={(e) => setFormPassword(e.target.value)}
                placeholder="Minimal 4 karakter"
                className="w-full pl-3.5 pr-10 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs placeholder-slate-500 focus:border-red-500 outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-300"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* 3. Konfirmasi Password */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300 block">
              Konfirmasi Password <span className="text-red-400">*</span>
            </label>
            <input
              type={showPassword ? 'text' : 'password'}
              required
              value={formConfirmPassword}
              onChange={(e) => setFormConfirmPassword(e.target.value)}
              placeholder="Ulangi password"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs placeholder-slate-500 focus:border-red-500 outline-none"
            />
          </div>

          {/* 4. Pilih Role (Harus ditulis lengkap: MEMBER, ADMIN, OWNER, DEVELOPER - Jangan disingkat DEV) */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 block">
              Pilih Role (Hak Akses Lengkap) <span className="text-red-400">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { role: 'MEMBER' as UserRole, desc: 'Akses Anggota Standar', allowed: true },
                {
                  role: 'ADMIN' as UserRole,
                  desc: 'Otoritas Pengelola',
                  allowed: currentUser?.role === 'OWNER' || currentUser?.role === 'DEVELOPER'
                },
                {
                  role: 'OWNER' as UserRole,
                  desc: 'Pemilik Sistem',
                  allowed: currentUser?.role === 'DEVELOPER'
                },
                {
                  role: 'DEVELOPER' as UserRole,
                  desc: 'Akses Pengembang Tertinggi',
                  allowed: currentUser?.role === 'DEVELOPER'
                }
              ].map((item) => {
                const isSelected = formRole === item.role;
                return (
                  <button
                    key={item.role}
                    type="button"
                    disabled={!item.allowed}
                    onClick={() => setFormRole(item.role)}
                    className={`p-3 rounded-xl border text-left transition relative flex flex-col justify-between ${
                      !item.allowed
                        ? 'opacity-40 bg-slate-950/40 border-slate-800/60 cursor-not-allowed'
                        : isSelected
                        ? 'bg-red-600/20 border-red-500 text-white glow-red shadow-md'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="font-extrabold text-xs tracking-wider">{item.role}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-red-400" />}
                    </div>
                    <span className="text-[10px] text-slate-400 mt-1 leading-tight">
                      {item.allowed ? item.desc : 'Memerlukan Otoritas Lebih Tinggi'}
                    </span>
                  </button>
                );
              })}
            </div>
            <p className="text-[10px] text-slate-400 pl-0.5">
              * Role MEMBER tidak boleh membuat akun ADMIN, OWNER, atau DEVELOPER.
            </p>
          </div>

          {/* 5. Pilih Masa Aktif */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 block">
              Pilih Masa Aktif Akun <span className="text-red-400">*</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { duration: '1 HARI' as ValidityDuration, note: 'Tepat 24 Jam' },
                { duration: '1 BULAN' as ValidityDuration, note: '1 Bulan Kalender' },
                { duration: 'PERMANEN' as ValidityDuration, note: 'Tanpa Batas Waktu' }
              ].map((item) => {
                const isSelected = formValidity === item.duration;
                return (
                  <button
                    key={item.duration}
                    type="button"
                    onClick={() => setFormValidity(item.duration)}
                    className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center justify-center ${
                      isSelected
                        ? 'bg-sky-500/20 border-sky-400 text-white glow-blue shadow-md'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <span className="font-extrabold text-xs tracking-wider">{item.duration}</span>
                    <span className="text-[9px] text-slate-400 mt-0.5">{item.note}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 6. Tombol BUAT AKUN */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-black text-xs uppercase tracking-widest shadow-[0_0_20px_rgba(220,38,38,0.45)] border border-red-400/40 active:scale-95 transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isSubmitting ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>MEMPROSES PEMBUATAN AKUN...</span>
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                <span>BUAT AKUN</span>
              </>
            )}
          </button>
        </form>
      )}

      {/* TAB 2: DAFTAR AKUN */}
      {activeTab === 'DAFTAR' && (
        <div className="space-y-3">
          {/* Search bar & Role Filters */}
          <div className="space-y-2">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari username, nama, atau role..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-sky-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white text-xs"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Filter Chips */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[10px]">
              {(['ALL', 'DEVELOPER', 'OWNER', 'ADMIN', 'MEMBER'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setRoleFilter(r)}
                  className={`px-3 py-1 rounded-lg font-bold uppercase transition whitespace-nowrap ${
                    roleFilter === r
                      ? 'bg-sky-500 text-white shadow'
                      : 'bg-slate-900 text-slate-400 hover:bg-slate-800 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {r === 'ALL' ? 'Semua Role' : r}
                </button>
              ))}
            </div>
          </div>

          {/* Accounts List */}
          {filteredUsers.length === 0 ? (
            <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-2">
              <Users className="w-8 h-8 text-slate-600 mx-auto" />
              <h3 className="text-xs font-bold text-white">Tidak Ada Akun Ditemukan</h3>
              <p className="text-[11px] text-slate-400">
                Coba sesuaikan kata kunci pencarian atau ganti filter role.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredUsers.map((user) => {
                const isAnsenAntonio = user.username.toLowerCase() === 'ansenantonio';
                const isExpired = user.status === 'KEDALUWARSA';
                const isDeactivated = user.status === 'NONAKTIF' || !user.isActive;

                return (
                  <div
                    key={user.id}
                    className={`p-4 rounded-2xl bg-slate-900/90 border transition space-y-3 shadow-lg ${
                      isAnsenAntonio
                        ? 'border-red-600/60 shadow-[0_0_15px_rgba(220,38,38,0.2)]'
                        : isExpired
                        ? 'border-amber-700/50 opacity-80'
                        : isDeactivated
                        ? 'border-slate-800 opacity-60'
                        : 'border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {/* User Header */}
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-xl overflow-hidden border border-slate-700 bg-black shrink-0 relative">
                          <img src={user.avatarUrl} alt={user.displayName} className="w-full h-full object-cover" />
                        </div>

                        <div>
                          <div className="flex items-center gap-1.5">
                            <h3 className="text-xs font-extrabold text-white truncate max-w-[150px]">
                              {user.displayName}
                            </h3>
                            {isAnsenAntonio && (
                              <span title="Pemilik & Developer Utama">
                                <Crown className="w-3.5 h-3.5 text-red-500 shrink-0" />
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] font-mono text-slate-400">@{user.username}</p>
                        </div>
                      </div>

                      {/* Badges */}
                      <div className="flex flex-col items-end gap-1">
                        <span
                          className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider border ${
                            user.role === 'DEVELOPER'
                              ? 'bg-red-600/20 text-red-400 border-red-500/40'
                              : user.role === 'OWNER'
                              ? 'bg-amber-600/20 text-amber-400 border-amber-500/40'
                              : user.role === 'ADMIN'
                              ? 'bg-sky-600/20 text-sky-400 border-sky-500/40'
                              : 'bg-slate-800 text-slate-300 border-slate-700'
                          }`}
                        >
                          {user.role}
                        </span>

                        <span
                          className={`px-1.5 py-0.2 rounded text-[8px] font-bold uppercase tracking-wider ${
                            isExpired
                              ? 'bg-amber-950 text-amber-400 border border-amber-800'
                              : isDeactivated
                              ? 'bg-red-950 text-red-400 border border-red-900'
                              : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          }`}
                        >
                          {user.status}
                        </span>
                      </div>
                    </div>

                    {/* Metadata Details */}
                    <div className="grid grid-cols-2 gap-2 text-[10px] p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                      <div>
                        <span className="text-slate-500 block">Masa Aktif:</span>
                        <span className="font-bold text-slate-300">{user.validity || 'PERMANEN'}</span>
                      </div>

                      <div>
                        <span className="text-slate-500 block">Kedaluwarsa:</span>
                        <span
                          className={`font-semibold ${
                            user.validity === 'PERMANEN'
                              ? 'text-sky-400 font-bold'
                              : isExpired
                              ? 'text-red-400 font-bold'
                              : 'text-slate-300'
                          }`}
                        >
                          {formatDateTime(user.expiresAt)}
                        </span>
                      </div>
                    </div>

                    {/* Actions Bar */}
                    <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                      <span className="text-[9px] font-mono text-slate-500">{user.id}</span>

                      <div className="flex items-center gap-1.5">
                        {isAnsenAntonio ? (
                          <span className="text-[10px] font-bold text-red-400 px-2 py-1 rounded bg-red-950/40 border border-red-900/50">
                            🛡️ Terproteksi Permanen
                          </span>
                        ) : (
                          <>
                            {/* Toggle Active / Deactivate */}
                            <button
                              onClick={() => toggleAccountActive(user.id)}
                              className={`p-1.5 rounded-lg border text-xs font-bold transition flex items-center gap-1 ${
                                user.isActive
                                  ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                                  : 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border-emerald-800'
                              }`}
                              title={user.isActive ? 'Nonaktifkan Akun' : 'Aktifkan Akun'}
                            >
                              <Power className="w-3.5 h-3.5" />
                              <span className="text-[10px]">{user.isActive ? 'Nonaktifkan' : 'Aktifkan'}</span>
                            </button>

                            {/* Edit */}
                            <button
                              onClick={() => {
                                setEditingUser(user);
                                setEditDisplayName(user.displayName);
                                setEditValidity(user.validity || '1 BULAN');
                              }}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
                              title="Edit Akun"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>

                            {/* Delete */}
                            <button
                              onClick={() => {
                                if (confirm(`Yakin ingin menghapus akun ${user.username}? Tindakan ini permanen.`)) {
                                  deleteAccount(user.id);
                                }
                              }}
                              className="p-1.5 rounded-lg bg-red-950/50 hover:bg-red-900 text-red-400 border border-red-900/60 transition"
                              title="Hapus Akun"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* MODAL 1: HASIL PEMBUATAN AKUN (Rincian Lengkap setelah Akun Berhasil Dibuat) */}
      {createdSummary && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border-2 border-emerald-500/80 p-5 shadow-2xl space-y-4 animate-scale-up">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2 text-emerald-400">
                <CheckCircle2 className="w-5 h-5" />
                <h3 className="text-sm font-black text-white">Akun Berhasil Dibuat!</h3>
              </div>
              <button
                onClick={() => setCreatedSummary(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Rincian akun baru telah terdaftar secara resmi di sistem DRK XXVII:
            </p>

            <div className="p-3.5 rounded-2xl bg-black/80 border border-slate-800 font-mono text-xs space-y-2">
              <div className="flex justify-between items-center pb-1.5 border-b border-slate-900">
                <span className="text-slate-400">Username:</span>
                <span className="font-bold text-white text-sm">@{createdSummary.username}</span>
              </div>

              <div className="flex justify-between items-center pb-1.5 border-b border-slate-900">
                <span className="text-slate-400">Role:</span>
                <span className="font-extrabold text-sky-400">{createdSummary.role}</span>
              </div>

              <div className="flex justify-between items-center pb-1.5 border-b border-slate-900">
                <span className="text-slate-400">Tanggal Pembuatan:</span>
                <span className="text-slate-300 text-[11px]">{createdSummary.createdAt}</span>
              </div>

              <div className="flex justify-between items-center pb-1.5 border-b border-slate-900">
                <span className="text-slate-400">Masa Aktif:</span>
                <span className="font-bold text-amber-400">{createdSummary.validity}</span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-slate-400">Tanggal Kedaluwarsa:</span>
                <span
                  className={`font-bold text-[11px] ${
                    createdSummary.expiresAt === 'PERMANEN' ? 'text-emerald-400' : 'text-red-400'
                  }`}
                >
                  {createdSummary.expiresAt}
                </span>
              </div>
            </div>

            {/* Actions in summary modal */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={copyCreatedSummaryText}
                className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition"
              >
                {copiedSummary ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copiedSummary ? 'Tersalin!' : 'Salin Rincian'}</span>
              </button>

              <button
                onClick={() => {
                  setCreatedSummary(null);
                  setActiveTab('DAFTAR');
                }}
                className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition"
              >
                Lihat di Daftar Akun
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: EDIT AKUN */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-700 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2 text-sky-400">
                <Edit3 className="w-4 h-4" />
                <h3 className="text-sm font-bold text-white">Edit Akun @{editingUser.username}</h3>
              </div>
              <button onClick={() => setEditingUser(null)} className="p-1 text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-400">Nama Tampilan</label>
                <input
                  type="text"
                  value={editDisplayName}
                  onChange={(e) => setEditDisplayName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-sky-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-400">Perbarui Masa Aktif</label>
                <select
                  value={editValidity}
                  onChange={(e) => setEditValidity(e.target.value as ValidityDuration)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-sky-500"
                >
                  <option value="1 HARI">1 HARI (24 Jam)</option>
                  <option value="1 BULAN">1 BULAN (1 Bulan Kalender)</option>
                  <option value="PERMANEN">PERMANEN (Tanpa Batas)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setEditingUser(null)}
                className="py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
              >
                Batal
              </button>
              <button
                onClick={handleSaveEdit}
                disabled={isSavingEdit}
                className="py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition disabled:opacity-50"
              >
                {isSavingEdit ? 'Menyimpan...' : 'Simpan'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
