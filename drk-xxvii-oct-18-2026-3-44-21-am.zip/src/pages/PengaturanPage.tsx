import React, { useState } from 'react';
import {
  KeyRound,
  ShieldAlert,
  ShieldCheck,
  Check,
  Crown,
  Users,
  Smartphone,
  LogOut,
  Lock,
  Sparkles,
  Info
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';

interface PengaturanPageProps {
  onNavigateToApk: () => void;
  onNavigateToKelolaAkun?: () => void;
  onLogout: () => void;
}

export const PengaturanPage: React.FC<PengaturanPageProps> = ({
  onNavigateToApk,
  onNavigateToKelolaAkun,
  onLogout
}) => {
  const { currentUser, allUsers, authorizeRole, setDirectUser } = useAuth();

  const [authKey, setAuthKey] = useState('');
  const [authResult, setAuthResult] = useState<{ success: boolean; message: string } | null>(null);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [passwordToast, setPasswordToast] = useState(false);

  const handleAuthorize = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authKey.trim()) return;

    const result = authorizeRole(authKey);
    setAuthResult(result);
    setAuthKey('');
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 4) {
      alert('Password baru minimal 4 karakter');
      return;
    }
    setPasswordToast(true);
    setCurrentPassword('');
    setNewPassword('');
    setTimeout(() => setPasswordToast(false), 2500);
  };

  const isPrivileged = currentUser?.role === 'DEVELOPER' || currentUser?.role === 'OWNER';

  return (
    <div className="p-4 space-y-4 max-w-md mx-auto pb-24 select-none">
      {/* Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-[#0c1424] border border-slate-700 shadow-xl space-y-1">
        <h1 className="text-lg font-black text-white font-display">
          Pengaturan Akun & Keamanan
        </h1>
        <p className="text-[11px] text-slate-400">
          Konfigurasi hak akses, otorisasi role khusus, dan sistem keamanan
        </p>
      </div>

      {/* Role Authorization Form - Strict system authorization requirement */}
      <div className="p-5 rounded-2xl bg-slate-900/95 border-2 border-slate-800 space-y-4 shadow-xl">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-sky-400" />
            <h3 className="text-sm font-extrabold text-white">
              Sistem Otorisasi Role Khusus
            </h3>
          </div>
          <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-400/40">
            Sistem Terproteksi
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          Sesuai aturan sistem, hak akses <strong>ADMIN</strong>, <strong>OWNER</strong>, dan <strong>DEVELOPER</strong> hanya dapat diaktifkan melalui kunci otorisasi resmi.
        </p>

        {authResult && (
          <div
            className={`p-3 rounded-xl text-xs flex items-start gap-2 border ${
              authResult.success
                ? 'bg-emerald-950/80 border-emerald-700 text-emerald-300'
                : 'bg-red-950/80 border-red-700 text-red-300'
            }`}
          >
            {authResult.success ? (
              <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
            ) : (
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
            )}
            <span>{authResult.message}</span>
          </div>
        )}

        <form onSubmit={handleAuthorize} className="space-y-3">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-400">
              Kunci Otorisasi Sistem
            </label>
            <input
              type="text"
              value={authKey}
              onChange={(e) => setAuthKey(e.target.value)}
              placeholder="Contoh: DRK-DEV-XXVII / DRK-OWNER-71"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm font-mono text-white placeholder-slate-600 focus:border-sky-500 outline-none uppercase"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg active:scale-95 transition"
          >
            Validasi & Terapkan Otorisasi
          </button>
        </form>

        <div className="p-2.5 rounded-xl bg-slate-950 text-[10px] text-slate-400 flex items-center gap-1.5 border border-slate-800">
          <Info className="w-3.5 h-3.5 text-sky-400 shrink-0" />
          <span>Kunci diberikan secara langsung oleh pengembang utama sistem.</span>
        </div>
      </div>

      {/* Password Change Form */}
      <form onSubmit={handleChangePassword} className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3 shadow-xl">
        <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-300 flex items-center gap-2 pb-1 border-b border-slate-800">
          <Lock className="w-4 h-4 text-red-400" />
          <span>Keamanan Kata Sandi</span>
        </h3>

        <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-400">
            Kata Sandi Sekarang
          </label>
          <input
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            placeholder="Kata sandi saat ini"
            className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:border-sky-500 outline-none"
          />
        </div>

        <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-400">
            Kata Sandi Baru
          </label>
          <input
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="Kata sandi baru"
            className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:border-sky-500 outline-none"
          />
        </div>

        <button
          type="submit"
          className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition"
        >
          Perbarui Kata Sandi
        </button>

        {passwordToast && (
          <div className="p-2 rounded-lg bg-emerald-900/80 text-emerald-200 text-xs font-semibold text-center">
            Kata sandi berhasil diperbarui!
          </div>
        )}
      </form>

      {/* Menu Kelola Akun Card */}
      {onNavigateToKelolaAkun && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/50 via-slate-900 to-slate-950 border border-amber-600/50 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-extrabold text-white">Menu Kelola Akun</h4>
              <p className="text-[10px] text-slate-400">Buat akun baru & atur hak akses role</p>
            </div>
          </div>

          <button
            onClick={onNavigateToKelolaAkun}
            className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs uppercase tracking-wider active:scale-95 transition"
          >
            Buka
          </button>
        </div>
      )}

      {/* Android APK Direct Link Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-slate-950 border border-emerald-800/60 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-extrabold text-white">Pusat APK Android</h4>
            <p className="text-[10px] text-slate-400">Status build & install di HP</p>
          </div>
        </div>

        <button
          onClick={onNavigateToApk}
          className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider active:scale-95 transition"
        >
          Buka APK
        </button>
      </div>

      {/* Logout Action */}
      <button
        onClick={onLogout}
        className="w-full py-3 rounded-2xl bg-red-950/40 hover:bg-red-900/40 text-red-400 hover:text-red-300 border border-red-900/60 text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition"
      >
        <LogOut className="w-4 h-4" />
        <span>Keluar dari Akun</span>
      </button>
    </div>
  );
};
