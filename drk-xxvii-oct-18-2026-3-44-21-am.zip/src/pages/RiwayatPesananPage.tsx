import React from 'react';
import {
  Clock,
  CheckCircle,
  AlertCircle,
  XCircle,
  MessageCircle,
  ShoppingBag,
  ExternalLink,
  Shield,
  Send,
  RefreshCw
} from 'lucide-react';
import { useOrders } from '../context/OrderContext';
import { useAuth } from '../context/AuthContext';
import { OrderStatus } from '../types';

interface RiwayatPesananPageProps {
  onNavigateToPembelian: () => void;
  onNavigateToKontak: () => void;
}

export const RiwayatPesananPage: React.FC<RiwayatPesananPageProps> = ({
  onNavigateToPembelian,
  onNavigateToKontak
}) => {
  const { orders, openTelegramForOrder, cancelOrder } = useOrders();
  const { currentUser } = useAuth();

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'Aktif':
        return (
          <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <CheckCircle className="w-3 h-3" />
            <span>Aktif</span>
          </span>
        );
      case 'Sedang Diproses':
        return (
          <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/20 text-sky-400 border border-sky-500/30">
            <RefreshCw className="w-3 h-3 animate-spin" />
            <span>Sedang Diproses</span>
          </span>
        );
      case 'Dibatalkan':
        return (
          <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-500/20 text-red-400 border border-red-500/30">
            <XCircle className="w-3 h-3" />
            <span>Dibatalkan</span>
          </span>
        );
      case 'Menunggu Konfirmasi':
      default:
        return (
          <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
            <AlertCircle className="w-3 h-3" />
            <span>Menunggu Konfirmasi</span>
          </span>
        );
    }
  };

  return (
    <div className="p-4 space-y-4 max-w-md mx-auto pb-24 select-none">
      {/* Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-[#0c1424] border border-slate-700 shadow-xl space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-sky-400">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <h1 className="text-lg font-black text-white font-display">
                Riwayat Pesanan
              </h1>
              <p className="text-[11px] text-slate-400">
                Data pesanan dan status verifikasi akun Anda
              </p>
            </div>
          </div>

          <button
            onClick={onNavigateToPembelian}
            className="px-3 py-1.5 rounded-xl bg-red-600/20 hover:bg-red-600/30 border border-red-500/50 text-red-300 text-xs font-bold transition flex items-center gap-1"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Pesan Lagi</span>
          </button>
        </div>
      </div>

      {/* Orders List */}
      {orders.length === 0 ? (
        <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-3">
          <ShoppingBag className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-sm font-bold text-white">Belum Ada Pesanan</h3>
          <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
            Anda belum memiliki riwayat pemesanan. Buka menu Pembelian untuk memilih lisensi atau modul yang Anda inginkan.
          </p>
          <button
            onClick={onNavigateToPembelian}
            className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-red-600 to-red-700 text-white font-bold text-xs uppercase tracking-wider shadow-lg active:scale-95 transition"
          >
            Buka Menu Pembelian
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((order) => {
            return (
              <div
                key={order.id}
                className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 shadow-xl space-y-3 transition"
              >
                {/* Header item */}
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-white">
                      {order.id}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {order.createdAt}
                    </span>
                  </div>
                  {getStatusBadge(order.status)}
                </div>

                {/* Details */}
                <div>
                  <h3 className="text-sm font-extrabold text-white">
                    {order.packageName}
                  </h3>
                  <div className="mt-1 text-xs text-slate-300 flex items-center gap-1.5">
                    <span className="text-slate-400">Tujuan Kontak:</span>
                    <span className="font-bold text-sky-400">
                      {order.targetContact} ({order.telegramHandle})
                    </span>
                  </div>
                  {order.notes && (
                    <p className="text-[11px] text-slate-400 mt-1 bg-slate-950/70 p-2 rounded-lg border border-slate-800/80">
                      {order.notes}
                    </p>
                  )}
                </div>

                {/* Status Notice */}
                <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-slate-400" />
                  <span>
                    {order.status === 'Aktif'
                      ? 'Layanan telah terkonfirmasi dan aktif pada akun Anda.'
                      : 'Pembayaran dan aktivasi divalidasi setelah konfirmasi via Telegram.'}
                  </span>
                </div>

                {/* Action Buttons */}
                <div className="pt-1 flex items-center gap-2">
                  <button
                    onClick={() => openTelegramForOrder(order)}
                    className="flex-1 py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow transition active:scale-95"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Lanjutkan ke Telegram</span>
                  </button>

                  {order.status === 'Menunggu Konfirmasi' && (
                    <button
                      onClick={() => cancelOrder(order.id)}
                      className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-red-400 text-xs font-bold transition"
                    >
                      Batal
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Payment and Verification Transparency Policy */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs text-slate-400">
        <h4 className="font-bold text-slate-200 flex items-center gap-1.5">
          <Shield className="w-4 h-4 text-sky-400" />
          <span>Protokol Verifikasi Pembayaran DRK XXVII</span>
        </h4>
        <p className="leading-relaxed">
          Seluruh pesanan diproses berdasarkan konfirmasi resmi bersama Pemilik (@AZXV71) atau Admin (@Danzxwoilah). Kami tidak menyatakan pembayaran berhasil secara otomatis sebelum bukti transaksi divalidasi.
        </p>
        <button
          onClick={onNavigateToKontak}
          className="text-sky-400 hover:underline font-semibold block pt-1"
        >
          Lihat kontak resmi di Menu Kontak &rarr;
        </button>
      </div>
    </div>
  );
};
