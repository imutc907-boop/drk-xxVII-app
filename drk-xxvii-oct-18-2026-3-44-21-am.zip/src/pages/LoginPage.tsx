import React, { useState } from 'react';
import { User as UserIcon, Lock, Eye, EyeOff, ShieldCheck, KeyRound, Sparkles, AlertCircle, RefreshCw } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface LoginPageProps {
  onSuccess: () => void;
  onOpenDeveloperAuth: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onSuccess, onOpenDeveloperAuth }) => {
  const { login, register } = useAuth();
  const [isRegisterMode, setIsRegisterMode] = useState(false);

  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [infoMsg, setInfoMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setInfoMsg('');
    setIsLoading(true);

    try {
      if (isRegisterMode) {
        const res = await register(username, displayName || username, password);
        if (res.success) {
          setInfoMsg(res.message);
          setTimeout(() => {
            onSuccess();
          }, 600);
        } else {
          setErrorMsg(res.message);
        }
      } else {
        const res = await login(username, password);
        if (res.success) {
          setInfoMsg(res.message);
          setTimeout(() => {
            onSuccess();
          }, 500);
        } else {
          setErrorMsg(res.message);
        }
      }
    } catch {
      setErrorMsg('Terjadi kendala saat memproses autentikasi. Silakan coba kembali.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickDeveloperLogin = async () => {
    setErrorMsg('');
    setInfoMsg('');
    setIsLoading(true);
    const res = await login('ansenantonio', 'developer2026');
    setIsLoading(false);
    if (res.success) {
      setInfoMsg('Berhasil masuk sebagai Pengembang: ANSEN ANTONIO (PERMANEN)');
      setTimeout(() => {
        onSuccess();
      }, 500);
    } else {
      setErrorMsg(res.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-white flex flex-col justify-between p-6 max-w-md mx-auto select-none">
      {/* Top App Icon matching user screenshot */}
      <div className="flex flex-col items-center pt-8">
        <div className="w-24 h-24 rounded-3xl overflow-hidden border-2 border-sky-400/60 shadow-[0_0_25px_rgba(56,189,248,0.45)] bg-black p-0.5 relative group">
          <img
            src="/drk_avatar.jpg"
            alt="DRK XXVII"
            className="w-full h-full object-cover rounded-[22px]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent rounded-[22px]" />
          <span className="absolute bottom-1.5 left-0 right-0 text-center text-[9px] font-black tracking-widest text-sky-300 uppercase">
            DRK XXVII
          </span>
        </div>

        <h1 className="text-3xl font-black text-white mt-6 font-display tracking-tight">
          Welcome <span className="text-sky-400">Back</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          {isRegisterMode ? 'Daftar akun anggota baru DRK XXVII' : 'Masuk ke akun Anda'}
        </p>
      </div>

      {/* Login / Register Form */}
      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-red-950/80 border border-red-800 text-red-300 text-xs flex items-start gap-2.5 shadow-lg">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
            <span className="leading-snug">{errorMsg}</span>
          </div>
        )}

        {infoMsg && (
          <div className="p-3.5 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-xs flex items-start gap-2.5 shadow-lg">
            <Sparkles className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
            <span className="leading-snug">{infoMsg}</span>
          </div>
        )}

        {/* Username */}
        <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-400 pl-1">
            Username
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
              <UserIcon className="w-4 h-4" />
            </div>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username akun"
              className="w-full pl-10 pr-4 py-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-white text-sm placeholder-slate-500 outline-none transition"
            />
          </div>
        </div>

        {/* Display Name (Register only) */}
        {isRegisterMode && (
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-400 pl-1">
              Nama Lengkap / Panggilan
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                <Sparkles className="w-4 h-4" />
              </div>
              <input
                type="text"
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Nama lengkap Anda"
                className="w-full pl-10 pr-4 py-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-white text-sm placeholder-slate-500 outline-none transition"
              />
            </div>
          </div>
        )}

        {/* Password */}
        <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-400 pl-1">
            Password
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
              <Lock className="w-4 h-4" />
            </div>
            <input
              type={showPassword ? 'text' : 'password'}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Kata sandi"
              className="w-full pl-10 pr-11 py-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-white text-sm placeholder-slate-500 outline-none transition"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-500 hover:text-slate-300"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Sign In Button */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full mt-2 py-3.5 rounded-2xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-extrabold text-sm shadow-[0_4px_20px_rgba(2,132,199,0.4)] border border-sky-400/40 transition active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isLoading ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>MEMERIKSA KREDENSIAL...</span>
            </>
          ) : (
            <span>{isRegisterMode ? 'Daftar Akun Baru' : 'Sign in'}</span>
          )}
        </button>

        {/* Toggle Register / Login */}
        <div className="text-center pt-2">
          <button
            type="button"
            onClick={() => {
              setIsRegisterMode(!isRegisterMode);
              setErrorMsg('');
              setInfoMsg('');
            }}
            className="text-xs text-slate-400 hover:text-sky-400 transition"
          >
            {isRegisterMode
              ? 'Sudah punya akun? Masuk di sini'
              : 'Belum memiliki akun? Buat Akun Anggota'}
          </button>
        </div>
      </form>

      {/* Developer? Click - Exactly as seen in user's screenshot! */}
      <div className="pt-6 pb-4 text-center space-y-3">
        <button
          type="button"
          onClick={handleQuickDeveloperLogin}
          className="text-xs text-slate-400 hover:text-white transition font-medium"
        >
          Developer? <span className="text-sky-400 font-extrabold underline decoration-sky-500 underline-offset-4">Click</span>
        </button>

        <div className="flex justify-center">
          <button
            type="button"
            onClick={onOpenDeveloperAuth}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-400 hover:text-slate-200"
          >
            <KeyRound className="w-3.5 h-3.5 text-red-400" />
            <span>Kunci Otorisasi Role Khusus</span>
          </button>
        </div>

        <p className="text-[10px] text-slate-600">
          © 2026 DRK XXVII
        </p>
      </div>
    </div>
  );
};
