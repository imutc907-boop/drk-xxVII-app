import React, { useState } from 'react';
import {
  ShoppingBag,
  ShieldCheck,
  CheckCircle,
  MessageCircle,
  ExternalLink,
  Crown,
  Sparkles,
  ArrowRight,
  UserCheck,
  Clock,
  X
} from 'lucide-react';
import { AVAILABLE_PACKAGES, useOrders } from '../context/OrderContext';
import { useAuth } from '../context/AuthContext';
import { ServicePackage, Order } from '../types';

interface PembelianPageProps {
  onNavigateToHistory: () => void;
  onNavigateToContact: () => void;
}

export const PembelianPage: React.FC<PembelianPageProps> = ({
  onNavigateToHistory,
  onNavigateToContact
}) => {
  const { currentUser } = useAuth();
  const { createOrder, openTelegramForOrder } = useOrders();

  const [selectedPackage, setSelectedPackage] = useState<ServicePackage | null>(null);
  const [selectedContact, setSelectedContact] = useState<'PEMILIK' | 'ADMIN'>('PEMILIK');
  const [orderNotes, setOrderNotes] = useState('');
  const [lastCreatedOrder, setLastCreatedOrder] = useState<Order | null>(null);

  const handleStartPurchase = (pkg: ServicePackage) => {
    setSelectedPackage(pkg);
    setOrderNotes('');
  };

  const handleConfirmOrder = () => {
    if (!selectedPackage) return;

    const newOrder = createOrder(selectedPackage, selectedContact, orderNotes);
    setLastCreatedOrder(newOrder);
    setSelectedPackage(null);

    // Open Telegram immediately as required
    openTelegramForOrder(newOrder);
  };

  return (
    <div className="p-4 space-y-4 max-w-md mx-auto pb-24 select-none">
      {/* Header Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-red-950 via-slate-900 to-black border border-red-800/60 shadow-xl relative overflow-hidden">
        <div className="relative z-10 space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-red-600 text-white shadow">
              PEMBELIAN RESMI
            </span>
            <span className="text-xs text-slate-400">DRK XXVII</span>
          </div>
          <h1 className="text-xl font-black text-white font-display tracking-wide mt-1">
            Menu Pembelian Layanan
          </h1>
          <p className="text-xs text-slate-300 leading-relaxed">
            Pilih paket layanan yang Anda butuhkan dan lanjutkan langsung untuk konfirmasi bersama tim terverifikasi.
          </p>
        </div>
      </div>

      {/* Package List without price list as mandated */}
      <div className="space-y-4">
        {AVAILABLE_PACKAGES.map((pkg) => {
          return (
            <div
              key={pkg.id}
              className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 shadow-xl transition space-y-4 relative overflow-hidden"
            >
              {pkg.badge && (
                <div className="absolute top-3 right-3">
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wider bg-sky-500/20 text-sky-400 border border-sky-400/40">
                    {pkg.badge}
                  </span>
                </div>
              )}

              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block">
                  {pkg.category}
                </span>
                <h3 className="text-base font-extrabold text-white mt-0.5">
                  {pkg.name}
                </h3>
                <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                  {pkg.description}
                </p>
              </div>

              {/* Feature bullets */}
              <div className="space-y-2 pt-2 border-t border-slate-800/80">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  Cakupan Fasilitas:
                </span>
                {pkg.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-slate-200">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span className="leading-tight">{feature}</span>
                  </div>
                ))}
              </div>

              <div className="pt-2 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  Rekomendasi: <strong className="text-sky-300">{pkg.recommendedRole}</strong>
                </span>

                {/* BELI SEKARANG BUTTON */}
                <button
                  onClick={() => handleStartPurchase(pkg)}
                  className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 active:scale-95 text-white font-black text-xs tracking-wider uppercase shadow-[0_0_15px_rgba(220,38,38,0.45)] border border-red-400/40 transition flex items-center gap-1.5"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>BELI SEKARANG</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick link to Order History */}
      <div className="pt-2 flex justify-between items-center px-1">
        <button
          onClick={onNavigateToHistory}
          className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition"
        >
          <Clock className="w-3.5 h-3.5 text-sky-400" />
          <span>Buka Riwayat Pesanan Saya</span>
        </button>

        <button
          onClick={onNavigateToContact}
          className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition"
        >
          <span>Buka Menu Kontak</span>
          <ArrowRight className="w-3.5 h-3.5 text-red-400" />
        </button>
      </div>

      {/* Order Modal: Target Contact Selection (Pemilik or Admin) & Telegram Routing */}
      {selectedPackage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-red-400" />
                <h3 className="text-base font-bold text-white">Alur Pemesanan</h3>
              </div>
              <button
                onClick={() => setSelectedPackage(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                Paket yang Dipilih:
              </span>
              <h4 className="text-sm font-bold text-white">
                {selectedPackage.name}
              </h4>
              <p className="text-[11px] text-slate-300">
                Pemesan: <strong className="text-sky-400">{currentUser?.displayName}</strong> ({currentUser?.id})
              </p>
            </div>

            {/* Choose Target Contact: PEMILIK or ADMIN */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 block">
                Pilih Kontak Tujuan Pemesanan:
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setSelectedContact('PEMILIK')}
                  className={`p-3 rounded-xl border text-center transition flex flex-col items-center justify-center ${
                    selectedContact === 'PEMILIK'
                      ? 'bg-red-600/20 border-red-500 text-white shadow-md glow-red'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <Crown className={`w-4 h-4 mb-1 ${selectedContact === 'PEMILIK' ? 'text-red-400' : 'text-slate-500'}`} />
                  <span className="text-xs font-black">PEMILIK</span>
                  <span className="text-[10px] text-slate-400">Jalur Utama</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedContact('ADMIN')}
                  className={`p-3 rounded-xl border text-center transition flex flex-col items-center justify-center ${
                    selectedContact === 'ADMIN'
                      ? 'bg-sky-600/20 border-sky-500 text-white shadow-md glow-blue'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <UserCheck className={`w-4 h-4 mb-1 ${selectedContact === 'ADMIN' ? 'text-sky-400' : 'text-slate-500'}`} />
                  <span className="text-xs font-black">ADMIN</span>
                  <span className="text-[10px] text-slate-400">Layanan Cepat</span>
                </button>
              </div>
            </div>

            {/* Order Note */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-400">
                Catatan Khusus (Opsional):
              </label>
              <input
                type="text"
                value={orderNotes}
                onChange={(e) => setOrderNotes(e.target.value)}
                placeholder="Contoh: Permintaan lisensi akun pribadi"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-red-500"
              />
            </div>

            <div className="text-[11px] text-slate-400 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
              ℹ Pesanan akan dicatat di <strong>Riwayat Pesanan</strong> dan membuka percakapan Telegram resmi untuk konfirmasi langsung.
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setSelectedPackage(null)}
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
              >
                Batal
              </button>

              <button
                type="button"
                onClick={handleConfirmOrder}
                className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white text-xs font-bold shadow-lg flex items-center justify-center gap-1.5 active:scale-95 transition"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Kirim Telegram</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success / Last Created Order Toast Card */}
      {lastCreatedOrder && (
        <div className="fixed bottom-20 left-4 right-4 max-w-sm mx-auto z-50 p-4 rounded-2xl bg-slate-900 border border-sky-500/60 shadow-2xl space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sky-400 font-bold text-xs">
              <CheckCircle className="w-4 h-4" />
              <span>Pesanan Tercatat: {lastCreatedOrder.id}</span>
            </div>
            <button
              onClick={() => setLastCreatedOrder(null)}
              className="text-slate-400 hover:text-white text-xs"
            >
              ✕
            </button>
          </div>
          <p className="text-[11px] text-slate-300">
            Status: <span className="text-amber-400 font-bold">{lastCreatedOrder.status}</span>. Silakan lanjutkan verifikasi di Telegram.
          </p>
          <button
            onClick={() => openTelegramForOrder(lastCreatedOrder)}
            className="w-full py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Buka Ulang Percakapan Telegram</span>
          </button>
        </div>
      )}
    </div>
  );
};
