import React, { useState } from 'react';
import {
  Smartphone,
  Send,
  Shield,
  Layers,
  Globe,
  User,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  Crown,
  ChevronRight,
  Terminal
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const WhatsAppToolsPage: React.FC = () => {
  const { currentUser } = useAuth();

  const [targetNumber, setTargetNumber] = useState('');
  const [selectedPayload, setSelectedPayload] = useState('#01 Crash invisible');
  const [selectedSender, setSelectedSender] = useState<'PRIVATE' | 'GLOBAL'>('PRIVATE');
  const [isSending, setIsSending] = useState(false);
  const [executionLog, setExecutionLog] = useState<string[]>([]);
  const [showLogModal, setShowLogModal] = useState(false);

  const payloads = [
    { id: '#01', name: 'Crash invisible' },
    { id: '#02', name: 'Delay Hard' },
    { id: '#03', name: 'Lock Chat' },
    { id: '#04', name: 'Payload Security Ping' },
    { id: '#05', name: 'Buffer Overload' }
  ];

  const handleSend = () => {
    if (!targetNumber.trim()) {
      alert('Silakan masukkan nomor target terlebih dahulu.');
      return;
    }

    setIsSending(true);
    setExecutionLog([
      `[${new Date().toLocaleTimeString()}] Menghubungkan ke gateway DRK XXVII...`,
      `[${new Date().toLocaleTimeString()}] Memverifikasi otorisasi user: ${currentUser?.displayName} (${currentUser?.role})`,
      `[${new Date().toLocaleTimeString()}] Menyiapkan payload: ${selectedPayload}`,
      `[${new Date().toLocaleTimeString()}] Menyalurkan melalui sender: ${selectedSender}`
    ]);
    setShowLogModal(true);

    setTimeout(() => {
      setExecutionLog((prev) => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] Mengenkripsi payload buffer...`,
        `[${new Date().toLocaleTimeString()}] Mengirim transmisi ke target: ${targetNumber}`
      ]);
    }, 1000);

    setTimeout(() => {
      setExecutionLog((prev) => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] Transmisi payload berhasil terkirim.`,
        `[${new Date().toLocaleTimeString()}] Sesi selesai dengan status 200 OK.`
      ]);
      setIsSending(false);
    }, 2200);
  };

  return (
    <div className="p-4 space-y-4 max-w-md mx-auto pb-24 select-none">
      {/* Top Banner - Matching IMG_20261017_210304_661.jpg */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-800 shadow-xl h-44 bg-black">
        <img
          src="/drk_warrior.jpg"
          alt="Warrior Banner"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#070b14] via-transparent to-black/40" />

        <div className="absolute top-2.5 left-3 text-[11px] font-mono text-sky-400">
          _drkxxvii
        </div>

        <div className="absolute top-2.5 right-3 text-right">
          <span className="text-xs font-black tracking-widest text-sky-300 drop-shadow">
            最強は、俺だ
          </span>
        </div>

        <div className="absolute bottom-2 left-3">
          <h2 className="text-lg font-black text-white font-display tracking-wider">
            DRK XXVII ENGINE
          </h2>
          <p className="text-[10px] text-slate-300">WhatsApp Payload & Testing Module</p>
        </div>
      </div>

      {/* Mini Profile Card */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl overflow-hidden border border-sky-400/60 glow-blue bg-black shrink-0">
            <img
              src={currentUser?.avatarUrl || '/drk_avatar.jpg'}
              alt={currentUser?.displayName}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block -mb-0.5">Welcome back,</span>
            <div className="text-sm font-black text-white font-display">
              {currentUser?.displayName || 'ANSEN ANTONIO'}
            </div>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="px-2 py-0.5 rounded text-[9px] font-extrabold bg-sky-500/20 text-sky-300 border border-sky-400/40">
                {currentUser?.role || 'DEVELOPER'}
              </span>
              <span className="px-2 py-0.5 rounded text-[9px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-400/40">
                {currentUser?.status || 'PERMANEN'}
              </span>
            </div>
          </div>
        </div>

        <div className="text-right">
          <span className="text-[9px] text-slate-400 block">ID User</span>
          <span className="text-xs font-mono font-bold text-slate-300">
            {currentUser?.id || 'DRK-2026-001'}
          </span>
        </div>
      </div>

      {/* Section 1: NOMOR TARGET */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
        <div className="flex items-center gap-2 text-xs font-extrabold text-white uppercase tracking-wider">
          <span className="w-1.5 h-3.5 bg-sky-500 rounded-full"></span>
          <Smartphone className="w-4 h-4 text-sky-400" />
          <span>NOMOR TARGET</span>
        </div>

        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
            <Smartphone className="w-4 h-4" />
          </div>
          <input
            type="tel"
            value={targetNumber}
            onChange={(e) => setTargetNumber(e.target.value)}
            placeholder="Contoh: +62xxxxxxxxxxx"
            className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-950 border border-slate-800 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-white text-sm placeholder-slate-500 outline-none transition"
          />
        </div>
      </div>

      {/* Section 2: PILIH PAYLOAD */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between text-xs font-extrabold text-white uppercase tracking-wider">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-3.5 bg-sky-500 rounded-full"></span>
            <Layers className="w-4 h-4 text-sky-400" />
            <span>PILIH PAYLOAD</span>
          </div>
          <span className="text-[10px] text-slate-400 lowercase tracking-normal font-normal">
            &lt; geser &gt;
          </span>
        </div>

        {/* Scrollable Payload Badges */}
        <div className="flex gap-2.5 overflow-x-auto pb-1 scrollbar-none">
          {payloads.map((p) => {
            const isSelected = selectedPayload === `${p.id} ${p.name}`;
            return (
              <button
                key={p.id}
                onClick={() => setSelectedPayload(`${p.id} ${p.name}`)}
                className={`p-3 rounded-xl border flex flex-col items-center justify-between min-w-[125px] transition shrink-0 ${
                  isSelected
                    ? 'bg-sky-500/20 border-sky-400/80 text-white glow-blue shadow-lg'
                    : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-2">
                  <Shield className={`w-4 h-4 ${isSelected ? 'text-sky-400' : 'text-slate-500'}`} />
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                    isSelected ? 'bg-sky-400 text-black font-black' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {p.id}
                  </span>
                </div>
                <span className="text-xs font-bold text-center leading-tight">
                  {p.name}
                </span>
              </button>
            );
          })}
        </div>

        {/* Active Payload Info */}
        <div className="p-2.5 rounded-xl bg-sky-500/10 border border-sky-500/25 flex items-center gap-2 text-xs text-sky-300">
          <div className="w-4 h-4 rounded-full bg-sky-500/20 flex items-center justify-center text-[10px] font-bold">
            i
          </div>
          <span>Payload aktif: <strong>{selectedPayload}</strong></span>
        </div>
      </div>

      {/* Section 3: PILIH SENDER */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between text-xs font-extrabold text-white uppercase tracking-wider">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-3.5 bg-sky-500 rounded-full"></span>
            <Send className="w-4 h-4 text-sky-400" />
            <span>PILIH SENDER</span>
          </div>
          <span className="text-[10px] text-slate-400 lowercase tracking-normal font-normal">
            &lt; geser &gt;
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {/* PRIVATE */}
          <button
            onClick={() => setSelectedSender('PRIVATE')}
            className={`p-3.5 rounded-xl border flex flex-col items-center justify-center text-center transition ${
              selectedSender === 'PRIVATE'
                ? 'bg-sky-500/20 border-sky-400 text-white shadow-md glow-blue'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <User className={`w-6 h-6 mb-1.5 ${selectedSender === 'PRIVATE' ? 'text-sky-400' : 'text-slate-500'}`} />
            <span className="text-xs font-extrabold tracking-wider">PRIVATE</span>
            <span className="text-[10px] text-slate-400 mt-1">Sender Pribadi</span>
          </button>

          {/* GLOBAL */}
          <button
            onClick={() => setSelectedSender('GLOBAL')}
            className={`p-3.5 rounded-xl border flex flex-col items-center justify-center text-center transition ${
              selectedSender === 'GLOBAL'
                ? 'bg-sky-500/20 border-sky-400 text-white shadow-md glow-blue'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <Globe className={`w-6 h-6 mb-1.5 ${selectedSender === 'GLOBAL' ? 'text-sky-400' : 'text-slate-500'}`} />
            <span className="text-xs font-extrabold tracking-wider">GLOBAL</span>
            <span className="text-[10px] text-slate-400 mt-1">Sender Global Aktif</span>
          </button>
        </div>

        <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
          <span className="text-sky-400 font-bold">ℹ</span>
          <span>
            {selectedSender === 'PRIVATE'
              ? 'Menggunakan sender pribadi dari session akun Anda'
              : 'Menggunakan dedicated relay server global berkecepatan tinggi'}
          </span>
        </div>
      </div>

      {/* Main Action Button - SEND BUG */}
      <button
        onClick={handleSend}
        disabled={isSending}
        className="w-full py-4 rounded-2xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-black text-sm tracking-widest uppercase flex items-center justify-center gap-2 shadow-[0_4px_25px_rgba(2,132,199,0.5)] border border-sky-400/40 active:scale-[0.98] transition disabled:opacity-50"
      >
        {isSending ? (
          <>
            <RotateCw className="w-5 h-5 animate-spin text-sky-200" />
            <span>MEMPROSES TRANSMISI...</span>
          </>
        ) : (
          <>
            <Send className="w-5 h-5 text-sky-200" />
            <span>SEND BUG</span>
          </>
        )}
      </button>

      {/* Execution Log Modal */}
      {showLogModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 p-5 shadow-2xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2 text-sky-400">
                <Terminal className="w-4 h-4" />
                <h3 className="text-sm font-bold text-white">Log Konsol Transmisi</h3>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                DRK XXVII
              </span>
            </div>

            <div className="p-3 rounded-xl bg-black font-mono text-[11px] text-sky-300 space-y-1.5 min-h-[140px] max-h-[220px] overflow-y-auto border border-slate-800">
              {executionLog.map((log, i) => (
                <div key={i} className="leading-snug">{log}</div>
              ))}
            </div>

            <button
              onClick={() => setShowLogModal(false)}
              className="w-full py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition"
            >
              Tutup Konsol
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
