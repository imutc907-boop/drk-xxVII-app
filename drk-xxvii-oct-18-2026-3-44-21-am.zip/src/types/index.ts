export type UserRole = 'MEMBER' | 'ADMIN' | 'OWNER' | 'DEVELOPER';

export type ValidityDuration = '1 HARI' | '1 BULAN' | 'PERMANEN';

export type UserStatus = 'PERMANEN' | 'AKTIF' | 'NONAKTIF' | 'KEDALUWARSA';

export interface User {
  id: string;
  username: string;
  displayName: string;
  role: UserRole;
  validity: ValidityDuration;
  expiresAt: string | null; // ISO string, or null for PERMANEN
  createdAt: string; // ISO string
  status: UserStatus;
  isActive: boolean;
  password?: string;
  createdBy?: string;
  avatarUrl: string;
  bio?: string;
  authorizedAt?: string;
}

export interface CreateAccountInput {
  username: string;
  password: string;
  confirmPassword: string;
  role: UserRole;
  validity: ValidityDuration;
  displayName?: string;
}

export interface CreatedAccountSummary {
  username: string;
  role: UserRole;
  createdAt: string;
  validity: ValidityDuration;
  expiresAt: string; // Formatted date string or "PERMANEN"
}

export interface CreateAccountResult {
  success: boolean;
  message: string;
  account?: CreatedAccountSummary;
}

export type OrderStatus = 'Menunggu Konfirmasi' | 'Sedang Diproses' | 'Aktif' | 'Dibatalkan';

export interface ServicePackage {
  id: string;
  name: string;
  category: string;
  description: string;
  features: string[];
  recommendedRole: string;
  badge?: string;
}

export interface Order {
  id: string;
  packageId: string;
  packageName: string;
  userId: string;
  username: string;
  targetContact: 'PEMILIK' | 'ADMIN';
  telegramHandle: string;
  status: OrderStatus;
  notes: string;
  createdAt: string;
  updatedAt: string;
}
