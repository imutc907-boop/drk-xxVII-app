import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  User,
  UserRole,
  ValidityDuration,
  UserStatus,
  CreateAccountInput,
  CreateAccountResult,
  CreatedAccountSummary
} from '../types';

export const DEFAULT_DEVELOPER: User = {
  id: 'DRK-2026-001',
  username: 'ansenantonio',
  displayName: 'ANSEN ANTONIO',
  role: 'DEVELOPER',
  validity: 'PERMANEN',
  expiresAt: null,
  createdAt: '2026-01-01T00:00:00.000Z',
  status: 'PERMANEN',
  isActive: true,
  password: 'developer2026',
  createdBy: 'SYSTEM_ROOT',
  avatarUrl: '/drk_avatar.jpg',
  bio: 'Lead Developer & Architect DRK XXVII Systems'
};

interface PermissionCheck {
  allowed: boolean;
  reason?: string;
}

interface AuthContextType {
  currentUser: User | null;
  allUsers: User[];
  isServerConnected: boolean;
  login: (username: string, pass: string) => Promise<{ success: boolean; message: string; user?: User }>;
  register: (username: string, displayName: string, pass: string) => Promise<{ success: boolean; message: string }>;
  logout: () => void;
  createAccount: (input: CreateAccountInput) => Promise<CreateAccountResult>;
  updateAccount: (id: string, updates: Partial<User>) => Promise<{ success: boolean; message: string }>;
  toggleAccountActive: (id: string) => Promise<{ success: boolean; message: string }>;
  deleteAccount: (id: string) => Promise<{ success: boolean; message: string }>;
  refreshAccounts: () => Promise<void>;
  updateProfilePhoto: (base64Photo: string) => void;
  updateProfileDetails: (displayName: string, bio: string) => void;
  authorizeRole: (authKey: string) => { success: boolean; message: string; newRole?: UserRole };
  setDirectUser: (user: User) => void;
  checkPermission: (action: 'CREATE_ACCOUNT' | 'MANAGE_ACCOUNTS' | 'DELETE_ACCOUNT', targetRole?: UserRole) => PermissionCheck;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

function evaluateLocalUserStatus(user: User): User {
  if (user.status === 'PERMANEN' || user.validity === 'PERMANEN') {
    return { ...user, status: 'PERMANEN', expiresAt: null };
  }

  if (user.expiresAt) {
    const expTime = new Date(user.expiresAt).getTime();
    if (Date.now() > expTime) {
      return { ...user, status: 'KEDALUWARSA', isActive: false };
    }
  }

  if (!user.isActive) {
    return { ...user, status: 'NONAKTIF' };
  }

  return { ...user, status: 'AKTIF' };
}

function calculateExpiryIso(validity: ValidityDuration): string | null {
  const now = new Date();
  if (validity === '1 HARI') {
    return new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString();
  }
  if (validity === '1 BULAN') {
    const exp = new Date(now.getTime());
    exp.setMonth(exp.getMonth() + 1);
    return exp.toISOString();
  }
  return null; // PERMANEN
}

export function formatDateTime(isoString: string | null): string {
  if (!isoString) return 'PERMANEN';
  try {
    const d = new Date(isoString);
    return d.toLocaleString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }) + ' WIB';
  } catch {
    return isoString;
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const savedUser = localStorage.getItem('drk_current_user');
      if (savedUser) {
        const parsed = JSON.parse(savedUser);
        return evaluateLocalUserStatus(parsed);
      }
      return DEFAULT_DEVELOPER;
    } catch {
      return DEFAULT_DEVELOPER;
    }
  });

  const [allUsers, setAllUsers] = useState<User[]>(() => {
    try {
      const savedUsers = localStorage.getItem('drk_users_list');
      if (savedUsers) {
        const list: User[] = JSON.parse(savedUsers);
        // Ensure default developer is always present
        const hasOwner = list.some((u) => u.username.toLowerCase() === 'ansenantonio');
        if (!hasOwner) {
          list.unshift(DEFAULT_DEVELOPER);
        }
        return list.map(evaluateLocalUserStatus);
      }
      return [DEFAULT_DEVELOPER];
    } catch {
      return [DEFAULT_DEVELOPER];
    }
  });

  const [isServerConnected, setIsServerConnected] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('drk_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('drk_current_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('drk_users_list', JSON.stringify(allUsers));
  }, [allUsers]);

  // Check backend server connection and fetch accounts if available
  const refreshAccounts = useCallback(async () => {
    try {
      const res = await fetch('/api/health');
      if (res.ok) {
        setIsServerConnected(true);
        if (currentUser && currentUser.role !== 'MEMBER') {
          const accRes = await fetch('/api/accounts', {
            headers: {
              'x-user-role': currentUser.role,
              'x-user-id': currentUser.id
            }
          });
          if (accRes.ok) {
            const data = await accRes.json();
            if (data.accounts) {
              setAllUsers(data.accounts);
            }
          }
        }
      } else {
        setIsServerConnected(false);
      }
    } catch {
      setIsServerConnected(false);
    }
  }, [currentUser]);

  useEffect(() => {
    refreshAccounts();
  }, [refreshAccounts]);

  // Permission checking utility for strict access control
  const checkPermission = (
    action: 'CREATE_ACCOUNT' | 'MANAGE_ACCOUNTS' | 'DELETE_ACCOUNT',
    targetRole?: UserRole
  ): PermissionCheck => {
    if (!currentUser) {
      return { allowed: false, reason: 'Harap masuk ke akun terlebih dahulu.' };
    }

    if (currentUser.role === 'MEMBER') {
      return {
        allowed: false,
        reason: 'Pengguna dengan role MEMBER tidak memiliki izin untuk mengelola atau membuat akun.'
      };
    }

    if (action === 'MANAGE_ACCOUNTS') {
      // ADMIN, OWNER, DEVELOPER can access management
      return { allowed: true };
    }

    if (action === 'CREATE_ACCOUNT') {
      if (!targetRole) return { allowed: true };

      if (currentUser.role === 'ADMIN') {
        if (targetRole !== 'MEMBER') {
          return {
            allowed: false,
            reason: 'Role ADMIN hanya memiliki otorisasi untuk membuat akun dengan role MEMBER.'
          };
        }
        return { allowed: true };
      }

      if (currentUser.role === 'OWNER') {
        if (targetRole === 'DEVELOPER') {
          return {
            allowed: false,
            reason: 'Role OWNER tidak dapat membuat akun dengan role DEVELOPER.'
          };
        }
        return { allowed: true };
      }

      if (currentUser.role === 'DEVELOPER') {
        return { allowed: true };
      }
    }

    if (action === 'DELETE_ACCOUNT') {
      if (currentUser.role === 'ADMIN') {
        if (targetRole !== 'MEMBER') {
          return {
            allowed: false,
            reason: 'Role ADMIN hanya dapat menghapus akun dengan role MEMBER.'
          };
        }
      }
      return { allowed: true };
    }

    return { allowed: true };
  };

  // Login handler
  const login = async (username: string, pass: string) => {
    const cleanUser = username.trim().toLowerCase();

    // Try backend API first
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: cleanUser, password: pass })
      });

      const data = await response.json();
      if (response.ok && data.success && data.user) {
        setIsServerConnected(true);
        const evalUser = evaluateLocalUserStatus(data.user);
        setCurrentUser(evalUser);
        return { success: true, message: data.message, user: evalUser };
      } else if (!response.ok && data.message) {
        // Direct server rejection (e.g. expired, deactivated, wrong password)
        return { success: false, message: data.message };
      }
    } catch (err) {
      console.warn('Backend login unavailable, evaluating client-side:', err);
    }

    // Client-side fallback authentication
    const found = allUsers.find((u) => u.username.toLowerCase() === cleanUser);
    if (!found) {
      return { success: false, message: 'Username tidak ditemukan. Periksa kembali username Anda.' };
    }

    const evalUser = evaluateLocalUserStatus(found);

    // Check Password
    if (evalUser.password && evalUser.password !== pass) {
      return { success: false, message: 'Password tidak sesuai. Periksa kembali karakter password Anda.' };
    }

    // Check Expiration
    if (evalUser.status === 'KEDALUWARSA') {
      const expDate = formatDateTime(evalUser.expiresAt);
      return {
        success: false,
        message: `Akses ditolak: Akun telah kedaluwarsa pada ${expDate}. Silakan hubungi admin atau pemilik.`
      };
    }

    // Check Deactivation
    if (evalUser.status === 'NONAKTIF' || !evalUser.isActive) {
      return {
        success: false,
        message: 'Akses ditolak: Akun ini telah dinonaktifkan oleh administrator. Hubungi pemilik atau admin.'
      };
    }

    setCurrentUser(evalUser);
    return { success: true, message: `Selamat datang kembali, ${evalUser.displayName}!`, user: evalUser };
  };

  // Public Register handler
  const register = async (username: string, displayName: string, pass: string) => {
    const cleanUser = username.trim().toLowerCase();
    if (!cleanUser || !displayName.trim()) {
      return { success: false, message: 'Username dan nama lengkap harus diisi.' };
    }
    if (pass.length < 4) {
      return { success: false, message: 'Password minimal 4 karakter.' };
    }

    // Try backend API first
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: cleanUser, displayName: displayName.trim(), password: pass })
      });
      const data = await response.json();
      if (response.ok && data.success && data.user) {
        setIsServerConnected(true);
        const evalUser = evaluateLocalUserStatus(data.user);
        setCurrentUser(evalUser);
        setAllUsers((prev) => [...prev, evalUser]);
        return { success: true, message: data.message };
      } else if (!response.ok && data.message) {
        return { success: false, message: data.message };
      }
    } catch {
      // Fallback
    }

    const exists = allUsers.some((u) => u.username.toLowerCase() === cleanUser);
    if (exists) {
      return { success: false, message: 'Username sudah digunakan, silakan pilih yang lain.' };
    }

    const newUser: User = {
      id: `DRK-2026-${Math.floor(100 + Math.random() * 900)}`,
      username: username.trim(),
      displayName: displayName.trim(),
      role: 'MEMBER',
      validity: '1 BULAN',
      expiresAt: calculateExpiryIso('1 BULAN'),
      createdAt: new Date().toISOString(),
      status: 'AKTIF',
      isActive: true,
      password: pass,
      createdBy: 'SELF_REGISTER',
      avatarUrl: '/drk_avatar.jpg'
    };

    setAllUsers((prev) => [...prev, newUser]);
    setCurrentUser(newUser);
    return { success: true, message: 'Pendaftaran anggota berhasil. Akun Anda berstatus MEMBER (1 BULAN).' };
  };

  const logout = () => {
    setCurrentUser(null);
  };

  // Create Account with Full Validation & Role Hierarchy
  const createAccount = async (input: CreateAccountInput): Promise<CreateAccountResult> => {
    if (!currentUser) {
      return { success: false, message: 'Anda harus masuk terlebih dahulu.' };
    }

    // Role check
    const perm = checkPermission('CREATE_ACCOUNT', input.role);
    if (!perm.allowed) {
      return { success: false, message: perm.reason || 'Izin ditolak.' };
    }

    // Input validations
    const cleanUser = input.username.trim();
    if (!cleanUser || !input.password || !input.confirmPassword || !input.role || !input.validity) {
      return {
        success: false,
        message: 'Semua kolom formulir wajib diisi.'
      };
    }

    if (input.password !== input.confirmPassword) {
      return {
        success: false,
        message: 'Konfirmasi password tidak cocok dengan password yang dimasukkan.'
      };
    }

    if (input.password.length < 4) {
      return {
        success: false,
        message: 'Password minimal 4 karakter.'
      };
    }

    // Try server API first
    try {
      const response = await fetch('/api/accounts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': currentUser.role,
          'x-user-name': currentUser.username
        },
        body: JSON.stringify(input)
      });
      const data = await response.json();
      if (response.ok && data.success) {
        await refreshAccounts();
        return {
          success: true,
          message: data.message,
          account: data.account
        };
      } else if (!response.ok && data.message) {
        return { success: false, message: data.message };
      }
    } catch {
      // Local fallback
    }

    // Duplicate check
    if (allUsers.some((u) => u.username.toLowerCase() === cleanUser.toLowerCase())) {
      return {
        success: false,
        message: `Username "${cleanUser}" sudah digunakan. Silakan gunakan username lain.`
      };
    }

    const createdAt = new Date().toISOString();
    const expiresAt = calculateExpiryIso(input.validity);
    const status: UserStatus = input.validity === 'PERMANEN' ? 'PERMANEN' : 'AKTIF';

    const newAccount: User = {
      id: `DRK-2026-${Math.floor(100 + Math.random() * 900)}`,
      username: cleanUser,
      displayName: (input.displayName || cleanUser).trim(),
      role: input.role,
      validity: input.validity,
      expiresAt,
      createdAt,
      status,
      isActive: true,
      password: input.password,
      createdBy: currentUser.username,
      avatarUrl: '/drk_avatar.jpg'
    };

    setAllUsers((prev) => [...prev, newAccount]);

    const formattedCreated = formatDateTime(createdAt);
    const formattedExpires = formatDateTime(expiresAt);

    const summary: CreatedAccountSummary = {
      username: newAccount.username,
      role: newAccount.role,
      createdAt: formattedCreated,
      validity: newAccount.validity,
      expiresAt: formattedExpires
    };

    return {
      success: true,
      message: `Akun ${cleanUser} berhasil dibuat dengan role ${input.role}!`,
      account: summary
    };
  };

  // Update Account
  const updateAccount = async (id: string, updates: Partial<User>) => {
    if (!currentUser) return { success: false, message: 'Harap masuk terlebih dahulu.' };

    const target = allUsers.find((u) => u.id === id);
    if (!target) return { success: false, message: 'Akun tidak ditemukan.' };

    // Protect Owner ANSEN ANTONIO
    if (target.username.toLowerCase() === 'ansenantonio') {
      if (updates.role && updates.role !== 'DEVELOPER') {
        return { success: false, message: 'Role akun utama ANSEN ANTONIO tidak dapat diubah.' };
      }
      if (updates.isActive === false) {
        return { success: false, message: 'Akun utama ANSEN ANTONIO tidak dapat dinonaktifkan.' };
      }
    }

    // Try server API first
    try {
      const response = await fetch(`/api/accounts/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': currentUser.role
        },
        body: JSON.stringify(updates)
      });
      if (response.ok) {
        const data = await response.json();
        await refreshAccounts();
        return { success: true, message: data.message };
      }
    } catch {
      // Local fallback
    }

    setAllUsers((prev) =>
      prev.map((u) => {
        if (u.id === id) {
          const updated = { ...u, ...updates };
          if (updates.validity) {
            updated.expiresAt = calculateExpiryIso(updates.validity);
          }
          return evaluateLocalUserStatus(updated);
        }
        return u;
      })
    );

    return { success: true, message: `Akun ${target.username} berhasil diperbarui.` };
  };

  // Toggle Active/Inactive
  const toggleAccountActive = async (id: string) => {
    const target = allUsers.find((u) => u.id === id);
    if (!target) return { success: false, message: 'Akun tidak ditemukan.' };

    if (target.username.toLowerCase() === 'ansenantonio') {
      return { success: false, message: 'Akun utama ANSEN ANTONIO tidak dapat dinonaktifkan.' };
    }

    const nextActive = !target.isActive;
    return await updateAccount(id, { isActive: nextActive });
  };

  // Delete Account
  const deleteAccount = async (id: string) => {
    if (!currentUser) return { success: false, message: 'Harap masuk terlebih dahulu.' };

    const target = allUsers.find((u) => u.id === id);
    if (!target) return { success: false, message: 'Akun tidak ditemukan.' };

    // PROTECT ANSEN ANTONIO
    if (target.username.toLowerCase() === 'ansenantonio') {
      return {
        success: false,
        message: 'Perlindungan Sistem: Akun pemilik & developer ANSEN ANTONIO (PERMANEN) tidak dapat dihapus!'
      };
    }

    const perm = checkPermission('DELETE_ACCOUNT', target.role);
    if (!perm.allowed) {
      return { success: false, message: perm.reason || 'Izin menghapus ditolak.' };
    }

    try {
      const response = await fetch(`/api/accounts/${id}`, {
        method: 'DELETE',
        headers: { 'x-user-role': currentUser.role }
      });
      if (response.ok) {
        await refreshAccounts();
        return { success: true, message: `Akun ${target.username} berhasil dihapus.` };
      }
    } catch {
      // Local fallback
    }

    setAllUsers((prev) => prev.filter((u) => u.id !== id));
    return { success: true, message: `Akun ${target.username} berhasil dihapus dari sistem.` };
  };

  const updateProfilePhoto = (base64Photo: string) => {
    if (!currentUser) return;
    const updated = { ...currentUser, avatarUrl: base64Photo };
    setCurrentUser(updated);
    setAllUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
  };

  const updateProfileDetails = (displayName: string, bio: string) => {
    if (!currentUser) return;
    const updated = { ...currentUser, displayName, bio };
    setCurrentUser(updated);
    setAllUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
  };

  const authorizeRole = (authKey: string) => {
    if (!currentUser) return { success: false, message: 'Harap masuk terlebih dahulu.' };

    const key = authKey.trim().toUpperCase();
    let newRole: UserRole | null = null;
    let newValidity: ValidityDuration = currentUser.validity || 'PERMANEN';
    let newStatus: UserStatus = currentUser.status;

    if (key === 'DRK-DEV-XXVII' || key === 'DRK-DEV' || key === 'AZXV71-DEV') {
      newRole = 'DEVELOPER';
      newValidity = 'PERMANEN';
      newStatus = 'PERMANEN';
    } else if (key === 'DRK-OWNER-71' || key === 'DRK-OWNER') {
      newRole = 'OWNER';
      newValidity = 'PERMANEN';
      newStatus = 'PERMANEN';
    } else if (key === 'DRK-ADMIN-27' || key === 'DRK-ADMIN') {
      newRole = 'ADMIN';
      newValidity = '1 BULAN';
      newStatus = 'AKTIF';
    }

    if (!newRole) {
      return {
        success: false,
        message: 'Kunci otorisasi tidak valid. Hubungi pengembang untuk kode akses khusus.'
      };
    }

    const updated: User = {
      ...currentUser,
      role: newRole,
      validity: newValidity,
      status: newStatus,
      expiresAt: newValidity === 'PERMANEN' ? null : calculateExpiryIso(newValidity),
      authorizedAt: new Date().toISOString()
    };

    setCurrentUser(updated);
    setAllUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));

    return {
      success: true,
      message: `Otorisasi berhasil! Akun Anda kini memiliki hak akses role ${newRole} (${newStatus}).`,
      newRole
    };
  };

  const setDirectUser = (user: User) => {
    setCurrentUser(user);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        allUsers,
        isServerConnected,
        login,
        register,
        logout,
        createAccount,
        updateAccount,
        toggleAccountActive,
        deleteAccount,
        refreshAccounts,
        updateProfilePhoto,
        updateProfileDetails,
        authorizeRole,
        setDirectUser,
        checkPermission
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
