import React, { createContext, useContext, useState, useEffect } from 'react';
import { Order, OrderStatus, ServicePackage } from '../types';

export const AVAILABLE_PACKAGES: ServicePackage[] = [
  {
    id: 'pkg-full-license',
    name: 'Akses Lisensi Permanen DRK XXVII',
    category: 'Lisensi & Keanggotaan',
    description: 'Hak akses lisensi utama DRK XXVII dengan status permanen dan dukungan prioritas langsung.',
    features: [
      'Akses Tanpa Batas Seluruh Modul DRK XXVII',
      'Status Akun Terverifikasi Permanen',
      'Pembaruan Sistem & Fitur Eksklusif',
      'Dukungan Teknis Jalur Cepat'
    ],
    recommendedRole: 'VIP & Developer',
    badge: 'UNGGULAN'
  },
  {
    id: 'pkg-wa-suite',
    name: 'Paket Dedicated Tools & WhatsApp Engine',
    category: 'Tools & Otomasi',
    description: 'Modul utilitas khusus untuk integrasi pesan terarah, multi-sender, dan pengujian stabilitas sistem.',
    features: [
      'Modul Private & Global Sender',
      'Payload System Stabilitas & Pengujian',
      'Konfigurasi Nomor Target Terproteksi',
      'Log Eksekusi & Antrean Pesan Otomatis'
    ],
    recommendedRole: 'Admin & Operator',
    badge: 'POPULER'
  },
  {
    id: 'pkg-server-custom',
    name: 'Paket Kustomisasi & Integrasi Server',
    category: 'Infrastruktur',
    description: 'Layanan pengaturan dedicated host, database terenkripsi, dan kustomisasi branding sistem.',
    features: [
      'Setup Host & Tunnel Terisolasi',
      'Enkripsi Data Pengguna Tingkat Lanjut',
      'Konsultasi Arsitektur Bersama Pemilik',
      'Integrasi Bot Telegram & Webhook Notifikasi'
    ],
    recommendedRole: 'Owner & Partner'
  }
];

interface OrderContextType {
  orders: Order[];
  createOrder: (packageItem: ServicePackage, target: 'PEMILIK' | 'ADMIN', userNotes?: string) => Order;
  cancelOrder: (orderId: string) => void;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  openTelegramForOrder: (order: Order) => void;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export const OrderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('drk_orders_list');
      if (saved) return JSON.parse(saved);
      // Clean initial order with accurate status
      return [
        {
          id: 'ORD-2026-7701',
          packageId: 'pkg-full-license',
          packageName: 'Akses Lisensi Permanen DRK XXVII',
          userId: 'DRK-2026-001',
          username: 'ansenantonio',
          targetContact: 'PEMILIK',
          telegramHandle: '@AZXV71',
          status: 'Aktif',
          notes: 'Lisensi resmi Developer Utama ANSEN ANTONIO terdaftar permanen.',
          createdAt: '2026-01-01 10:00:00',
          updatedAt: '2026-01-01 10:00:00'
        }
      ];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('drk_orders_list', JSON.stringify(orders));
  }, [orders]);

  const createOrder = (
    packageItem: ServicePackage,
    target: 'PEMILIK' | 'ADMIN',
    userNotes: string = ''
  ): Order => {
    const rawUser = localStorage.getItem('drk_current_user');
    const user = rawUser ? JSON.parse(rawUser) : null;
    const userId = user?.id || 'DRK-GUEST';
    const username = user?.username || 'Tamu';

    const newOrder: Order = {
      id: `ORD-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      packageId: packageItem.id,
      packageName: packageItem.name,
      userId,
      username,
      targetContact: target,
      telegramHandle: target === 'PEMILIK' ? '@AZXV71' : '@Danzxwoilah',
      status: 'Menunggu Konfirmasi',
      notes: userNotes || 'Pesanan diteruskan ke Telegram resmi untuk konfirmasi pembayaran dan aktivasi.',
      createdAt: new Date().toLocaleString('id-ID'),
      updatedAt: new Date().toLocaleString('id-ID')
    };

    setOrders((prev) => [newOrder, ...prev]);
    return newOrder;
  };

  const cancelOrder = (orderId: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? { ...o, status: 'Dibatalkan', updatedAt: new Date().toLocaleString('id-ID') }
          : o
      )
    );
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? { ...o, status, updatedAt: new Date().toLocaleString('id-ID') }
          : o
      )
    );
  };

  const openTelegramForOrder = (order: Order) => {
    const handle = order.targetContact === 'PEMILIK' ? 'AZXV71' : 'Danzxwoilah';
    const text = encodeURIComponent(
      `Halo DRK XXVII Team,\n\nSaya ingin memesan:\n📦 Layanan: ${order.packageName}\n🆔 No Pesanan: ${order.id}\n👤 User ID: ${order.userId} (${order.username})\n📌 Tujuan: ${order.targetContact} (@${handle})\n\nMohon petunjuk untuk konfirmasi dan aktivasi layanan.`
    );
    const url = `https://t.me/${handle}?text=${text}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <OrderContext.Provider
      value={{
        orders,
        createOrder,
        cancelOrder,
        updateOrderStatus,
        openTelegramForOrder
      }}
    >
      {children}
    </OrderContext.Provider>
  );
};

export const useOrders = () => {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrders must be used within an OrderProvider');
  }
  return context;
};
