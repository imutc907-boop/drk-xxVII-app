import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { OrderProvider } from './context/OrderContext';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { Drawer } from './components/Drawer';
import { WelcomeSplash } from './pages/WelcomeSplash';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { WhatsAppToolsPage } from './pages/WhatsAppToolsPage';
import { PembelianPage } from './pages/PembelianPage';
import { KontakPage } from './pages/KontakPage';
import { RiwayatPesananPage } from './pages/RiwayatPesananPage';
import { ProfilePage } from './pages/ProfilePage';
import { PengaturanPage } from './pages/PengaturanPage';
import { ApkBuildPage } from './pages/ApkBuildPage';
import { KelolaAkunPage } from './pages/KelolaAkunPage';

const MainApp: React.FC = () => {
  const { currentUser, logout, login } = useAuth();
  const [currentPage, setCurrentPage] = useState<string>(() => {
    // If user is already stored, go straight to dashboard; otherwise start at splash
    const saved = localStorage.getItem('drk_current_user');
    return saved ? 'dashboard' : 'splash';
  });
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleQuickDevLogin = () => {
    login('ansenantonio', 'developer2026');
    setCurrentPage('dashboard');
  };

  // Render splash screen if on splash
  if (currentPage === 'splash') {
    return (
      <WelcomeSplash
        onEnterApp={() => setCurrentPage('dashboard')}
        onGoToLogin={() => setCurrentPage('login')}
        onQuickDevLogin={handleQuickDevLogin}
      />
    );
  }

  // Render login screen if on login and not logged in
  if (currentPage === 'login' || !currentUser) {
    return (
      <LoginPage
        onSuccess={() => setCurrentPage('dashboard')}
        onOpenDeveloperAuth={() => setCurrentPage('pengaturan')}
      />
    );
  }

  const showBottomNav = [
    'dashboard',
    'whatsapp',
    'pembelian',
    'riwayat',
    'profile',
    'pengaturan',
    'kelola-akun'
  ].includes(currentPage);

  return (
    <div className="min-h-screen bg-[#05070d] text-slate-100 flex flex-col font-sans antialiased">
      {/* Top Mobile Navbar */}
      <Navbar
        currentPage={currentPage}
        onOpenDrawer={() => setIsDrawerOpen(true)}
        onNavigate={handleNavigate}
      />

      {/* Side Drawer */}
      <Drawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        onNavigate={handleNavigate}
        currentPage={currentPage}
      />

      {/* Main Page Content */}
      <main className="flex-1 w-full max-w-md mx-auto">
        {currentPage === 'dashboard' && (
          <DashboardPage onNavigate={handleNavigate} />
        )}

        {currentPage === 'kelola-akun' && (
          <KelolaAkunPage onBack={() => handleNavigate('dashboard')} />
        )}

        {currentPage === 'whatsapp' && (
          <WhatsAppToolsPage />
        )}

        {currentPage === 'pembelian' && (
          <PembelianPage
            onNavigateToHistory={() => handleNavigate('riwayat')}
            onNavigateToContact={() => handleNavigate('kontak')}
          />
        )}

        {currentPage === 'kontak' && (
          <KontakPage onBack={() => handleNavigate('dashboard')} />
        )}

        {currentPage === 'riwayat' && (
          <RiwayatPesananPage
            onNavigateToPembelian={() => handleNavigate('pembelian')}
            onNavigateToKontak={() => handleNavigate('kontak')}
          />
        )}

        {currentPage === 'profile' && (
          <ProfilePage
            onNavigateToSettings={() => handleNavigate('pengaturan')}
            onNavigateToApk={() => handleNavigate('apk-build')}
          />
        )}

        {currentPage === 'pengaturan' && (
          <PengaturanPage
            onNavigateToApk={() => handleNavigate('apk-build')}
            onNavigateToKelolaAkun={() => handleNavigate('kelola-akun')}
            onLogout={() => {
              logout();
              setCurrentPage('login');
            }}
          />
        )}

        {currentPage === 'apk-build' && (
          <ApkBuildPage onBack={() => handleNavigate('dashboard')} />
        )}
      </main>

      {/* Bottom Nav on mobile screens */}
      {showBottomNav && (
        <BottomNav currentPage={currentPage} onNavigate={handleNavigate} />
      )}
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <OrderProvider>
        <MainApp />
      </OrderProvider>
    </AuthProvider>
  );
}
