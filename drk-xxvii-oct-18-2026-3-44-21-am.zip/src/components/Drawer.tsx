import React from 'react';
import {
  X,
  LayoutGrid,
  ShoppingBag,
  Clock,
  MessageSquare,
  Headphones,
  User,
  Settings,
  Smartphone,
  LogOut,
  Users,
  ShieldCheck,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: string) => void;
  currentPage: string;
}

export const Drawer: React.FC<DrawerProps> = ({ isOpen, onClose, onNavigate, currentPage }) => {
  const { currentUser, logout } = useAuth();

  if (!isOpen) return null;

  const handleNav = (page: string) => {
    onNavigate(page);
    onClose();
  };

  const isPrivileged = currentUser?.role === 'ADMIN' || currentUser?.role === 'OWNER' || currentUser?.role === 'DEVELOPER';

  const menuItems = [
    { id: 'dashboard', label: 'Beranda Utama', icon: LayoutGrid },
    {
      id: 'kelola-akun',
      label: 'Kelola Akun (Buat Akun)',
      icon: Users,
      color: 'text-amber-400',
      badge: isPrivileged ? 'Otoritas' : 'Terkunci'
    },
    { id: 'pembelian', label: 'Menu Pembelian (Beli Sekarang)', icon: ShoppingBag, color: 'text-red-400' },
    { id: 'riwayat', label: 'Riwayat Pesanan', icon: Clock },
    { id: 'whatsapp', label: 'WhatsApp Tools & Engine', icon: MessageSquare },
    { id: 'kontak', label: 'Menu Kontak (Pemilik & Admin)', icon: Headphones, color: 'text-sky-400' },
    { id: 'profile', label: 'Profil Pengguna', icon: User },
    { id: 'pengaturan', label: 'Pengaturan & Otorisasi', icon: Settings },
    { id: 'apk-build', label: 'Pusat APK Android', icon: Smartphone, badge: 'Siap' },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 left-0 max-w-xs w-full bg-[#070b14] border-r border-slate-800 p-5 flex flex-col justify-between shadow-2xl z-50">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden border border-slate-700 bg-black">
                <img src="/drk_avatar.jpg" alt="DRK XXVII" className="w-full h-full object-cover" />
              </div>
              <div>
                <h2 className="text-base font-extrabold silver-gradient-text font-display">
                  DRK XXVII
                </h2>
                <p className="text-[10px] text-slate-400">Stronger • Safer • Together</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* User mini status */}
          {currentUser && (
            <div className="mt-4 p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg overflow-hidden border border-slate-700 bg-slate-950">
                  <img src={currentUser.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white truncate max-w-[130px]">
                    {currentUser.displayName}
                  </div>
                  <div className="text-[10px] text-slate-400">{currentUser.id}</div>
                </div>
              </div>

              <span className="px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider bg-red-600/20 text-red-400 border border-red-500/30">
                {currentUser.role}
              </span>
            </div>
          )}

          {/* Navigation Items */}
          <div className="mt-5 space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition ${
                    isActive
                      ? 'bg-sky-500/15 text-sky-400 border border-sky-500/30 shadow-sm'
                      : 'text-slate-300 hover:bg-slate-900/80 hover:text-white border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${item.color || (isActive ? 'text-sky-400' : 'text-slate-400')}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded border font-bold ${
                        item.badge === 'Otoritas'
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                          : item.badge === 'Terkunci'
                          ? 'bg-slate-800 text-slate-400 border-slate-700'
                          : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-slate-800 space-y-2">
          <div className="text-[10px] text-slate-500 flex items-center justify-between px-1">
            <span>DRK XXVII Official App</span>
            <span className="text-slate-400 font-mono">v2.7.0</span>
          </div>

          <button
            onClick={() => {
              logout();
              onClose();
              onNavigate('login');
            }}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-red-950/30 hover:bg-red-900/40 text-red-400 hover:text-red-300 border border-red-900/40 text-xs font-bold transition"
          >
            <LogOut className="w-4 h-4" />
            <span>Keluar Akun</span>
          </button>
        </div>
      </div>
    </div>
  );
};
