import React from 'react';
import { Menu, Headphones, Shield, User as UserIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  onOpenDrawer: () => void;
  onNavigate: (page: string) => void;
  currentPage: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenDrawer, onNavigate, currentPage }) => {
  const { currentUser } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-[#05070d]/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-3 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenDrawer}
          className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition"
          aria-label="Buka Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div
          onClick={() => onNavigate('dashboard')}
          className="flex items-center gap-2 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl overflow-hidden border border-sky-500/40 glow-blue shadow-inner flex items-center justify-center bg-slate-950">
            <img
              src="/drk_avatar.jpg"
              alt="DRK XXVII"
              className="w-full h-full object-cover group-hover:scale-105 transition"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold tracking-wider text-base silver-gradient-text font-display">
                DRK XXVII
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium tracking-tight">
              Dashboard Mobile
            </p>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {/* Discrete Contact button (shows details only when clicked) */}
        <button
          onClick={() => onNavigate('kontak')}
          className={`p-2 rounded-xl transition flex items-center gap-1.5 border ${
            currentPage === 'kontak'
              ? 'bg-red-600/20 border-red-500/60 text-red-400 shadow-[0_0_15px_rgba(239,68,68,0.3)]'
              : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
          }`}
          title="Buka Menu Kontak"
        >
          <Headphones className="w-4 h-4" />
          <span className="text-xs font-semibold pr-1 hidden sm:inline">Kontak</span>
        </button>

        {/* Profile Avatar Quick Link */}
        <button
          onClick={() => onNavigate('profile')}
          className="relative flex items-center justify-center p-0.5 rounded-xl border border-slate-700/80 hover:border-sky-500/60 transition overflow-hidden bg-slate-900"
          title="Buka Profil"
        >
          {currentUser?.avatarUrl ? (
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.displayName}
              className="w-8 h-8 rounded-lg object-cover"
            />
          ) : (
            <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-slate-300">
              <UserIcon className="w-4 h-4" />
            </div>
          )}
          {currentUser?.status === 'PERMANEN' && (
            <span
              className="absolute -top-1 -right-1 bg-red-600 text-white text-[8px] font-bold px-1 rounded-full border border-black shadow"
              title="Status Permanen"
            >
              P
            </span>
          )}
        </button>
      </div>
    </header>
  );
};
