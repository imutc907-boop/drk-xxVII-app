import React from 'react';
import { LayoutGrid, MessageSquare, ShoppingBag, Clock, UserCheck } from 'lucide-react';

interface BottomNavProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentPage, onNavigate }) => {
  const navItems = [
    {
      id: 'dashboard',
      label: 'Home',
      icon: LayoutGrid,
    },
    {
      id: 'whatsapp',
      label: 'WhatsApp',
      icon: MessageSquare,
    },
    {
      id: 'pembelian',
      label: 'Pembelian',
      icon: ShoppingBag,
      highlight: true,
    },
    {
      id: 'riwayat',
      label: 'Riwayat',
      icon: Clock,
    },
    {
      id: 'profile',
      label: 'Akun',
      icon: UserCheck,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#070b14]/95 backdrop-blur-lg border-t border-slate-800/80 px-2 py-2 max-w-md mx-auto sm:max-w-lg md:max-w-xl">
      <div className="grid grid-cols-5 gap-1 items-center">
        {navItems.map((item) => {
          const isActive = currentPage === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition relative group ${
                isActive
                  ? 'text-sky-400 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.highlight && !isActive && (
                <span className="absolute -top-1 right-2 w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
              )}

              <div
                className={`p-1 rounded-xl transition ${
                  isActive
                    ? 'bg-sky-500/15 text-sky-400 border border-sky-500/30 glow-blue'
                    : item.highlight
                    ? 'text-red-400'
                    : 'group-hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-5 h-5 transition-transform group-hover:scale-110" />
              </div>

              <span className={`text-[10px] mt-1 tracking-tight ${isActive ? 'text-sky-400 font-bold' : 'text-slate-400'}`}>
                {item.label}
              </span>

              {isActive && (
                <span className="w-4 h-0.5 bg-gradient-to-r from-sky-400 to-red-500 rounded-full mt-0.5"></span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
