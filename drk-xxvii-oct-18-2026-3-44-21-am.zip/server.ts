import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { User, UserRole, ValidityDuration, UserStatus } from './src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const DATA_DIR = path.resolve(__dirname, 'data');
const DATA_FILE = path.resolve(DATA_DIR, 'accounts.json');

app.use(express.json({ limit: '10mb' }));

// Ensure data folder and file exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export const DEFAULT_DEVELOPER: User = {
  id: 'DRK-2026-001',
  username: 'ansenantonio',
  displayName: 'ANSEN ANTONIO',
  role: 'DEVELOPER',
  validity: 'PERMANEN',
  expiresAt: null,
  createdAt: '2026-01-01T00:00:00.000Z',
  status: 'PERMANEN',
  isActive: true,
  password: 'developer2026',
  createdBy: 'SYSTEM_ROOT',
  avatarUrl: '/drk_avatar.jpg',
  bio: 'Lead Developer & Architect DRK XXVII Systems'
};

function loadAccounts(): User[] {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, 'utf-8');
      const data = JSON.parse(content);
      if (Array.isArray(data) && data.length > 0) {
        // Guarantee ANSEN ANTONIO is always present and uncompromised
        const hasOwner = data.some((u: User) => u.username.toLowerCase() === 'ansenantonio');
        if (!hasOwner) {
          data.unshift(DEFAULT_DEVELOPER);
          saveAccounts(data);
        }
        return data;
      }
    }
  } catch (err) {
    console.error('Gagal membaca data accounts.json:', err);
  }
  const init = [DEFAULT_DEVELOPER];
  saveAccounts(init);
  return init;
}

function saveAccounts(accounts: User[]): void {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(accounts, null, 2), 'utf-8');
  } catch (err) {
    console.error('Gagal menyimpan accounts.json:', err);
  }
}

// Helper to check and update expiration status
function evaluateUserStatus(user: User): User {
  if (user.status === 'PERMANEN' || user.validity === 'PERMANEN') {
    return { ...user, status: 'PERMANEN', expiresAt: null };
  }

  if (user.expiresAt) {
    const expTime = new Date(user.expiresAt).getTime();
    if (Date.now() > expTime) {
      return { ...user, status: 'KEDALUWARSA', isActive: false };
    }
  }

  if (!user.isActive) {
    return { ...user, status: 'NONAKTIF' };
  }

  return { ...user, status: 'AKTIF' };
}

// Calculate expiration date
function calculateExpiration(duration: ValidityDuration): string | null {
  const now = new Date();
  if (duration === '1 HARI') {
    return new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString();
  }
  if (duration === '1 BULAN') {
    const exp = new Date(now.getTime());
    exp.setMonth(exp.getMonth() + 1);
    return exp.toISOString();
  }
  return null; // PERMANEN
}

function formatExpirationDate(isoString: string | null): string {
  if (!isoString) return 'PERMANEN';
  try {
    const d = new Date(isoString);
    return d.toLocaleString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }) + ' WIB';
  } catch {
    return isoString;
  }
}

// API Routes

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ONLINE',
    app: 'DRK XXVII',
    storage: 'PERSISTENT_SERVER_BACKEND',
    timestamp: new Date().toISOString()
  });
});

// Authentication / Login with expiration & deactivation checks
app.post('/api/auth/login', (req: Request, res: Response): any => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Username dan password wajib diisi.' });
  }

  const cleanUser = username.trim().toLowerCase();
  const accounts = loadAccounts();
  const rawFound = accounts.find((u) => u.username.toLowerCase() === cleanUser);

  if (!rawFound) {
    return res.status(404).json({ success: false, message: 'Akun tidak ditemukan. Periksa kembali username Anda.' });
  }

  const found = evaluateUserStatus(rawFound);

  // Check password
  if (found.password && found.password !== password) {
    return res.status(401).json({ success: false, message: 'Password salah. Periksa kembali kombinasi karakter.' });
  }

  // Check Expiration
  if (found.status === 'KEDALUWARSA') {
    const expFormatted = formatExpirationDate(found.expiresAt);
    return res.status(403).json({
      success: false,
      message: `Akses ditolak: Akun telah kedaluwarsa pada ${expFormatted}. Silakan hubungi admin atau pemilik.`
    });
  }

  // Check Active status
  if (found.status === 'NONAKTIF' || !found.isActive) {
    return res.status(403).json({
      success: false,
      message: 'Akses ditolak: Akun ini telah dinonaktifkan oleh administrator. Hubungi pemilik atau admin.'
    });
  }

  return res.json({
    success: true,
    message: `Selamat datang kembali, ${found.displayName}!`,
    user: found
  });
});

// Public Member Registration
app.post('/api/auth/register', (req: Request, res: Response): any => {
  const { username, displayName, password } = req.body;
  const cleanUser = (username || '').trim().toLowerCase();
  if (!cleanUser || !displayName?.trim() || !password) {
    return res.status(400).json({ success: false, message: 'Semua kolom wajib diisi.' });
  }
  if (password.length < 4) {
    return res.status(400).json({ success: false, message: 'Password minimal 4 karakter.' });
  }

  const accounts = loadAccounts();
  if (accounts.some((u) => u.username.toLowerCase() === cleanUser)) {
    return res.status(409).json({ success: false, message: 'Username sudah digunakan. Silakan pilih username lain.' });
  }

  const newUser: User = {
    id: `DRK-2026-${Math.floor(100 + Math.random() * 900)}`,
    username: username.trim(),
    displayName: displayName.trim(),
    role: 'MEMBER', // Public register is strictly MEMBER
    validity: '1 BULAN',
    expiresAt: calculateExpiration('1 BULAN'),
    createdAt: new Date().toISOString(),
    status: 'AKTIF',
    isActive: true,
    password,
    createdBy: 'SELF_REGISTER',
    avatarUrl: '/drk_avatar.jpg'
  };

  accounts.push(newUser);
  saveAccounts(accounts);

  return res.json({
    success: true,
    message: 'Pendaftaran anggota berhasil.',
    user: newUser
  });
});

// Get all accounts (Requires admin/owner/developer role in header)
app.get('/api/accounts', (req: Request, res: Response): any => {
  const requesterRole = req.headers['x-user-role'] as string;
  const requesterId = req.headers['x-user-id'] as string;

  if (!requesterRole || requesterRole === 'MEMBER') {
    return res.status(403).json({
      success: false,
      message: 'Akses Ditolak: Menu KELOLA AKUN hanya dapat dibuka oleh ADMIN, OWNER, atau DEVELOPER.'
    });
  }

  const accounts = loadAccounts().map(evaluateUserStatus);
  // Hide password in response
  const sanitized = accounts.map(({ password, ...rest }) => rest);

  return res.json({
    success: true,
    accounts: sanitized,
    requesterRole
  });
});

// Create Account (Formulir BUAT AKUN dengan validasi izin ketat)
app.post('/api/accounts', (req: Request, res: Response): any => {
  const requesterRole = (req.headers['x-user-role'] as UserRole) || 'MEMBER';
  const requesterUsername = (req.headers['x-user-name'] as string) || 'unknown';

  // Permission: MEMBER cannot create accounts
  if (!requesterRole || requesterRole === 'MEMBER') {
    return res.status(403).json({
      success: false,
      message: 'Akses Ditolak: Anda tidak memiliki izin untuk membuat akun.'
    });
  }

  const { username, password, confirmPassword, role, validity, displayName } = req.body;

  // Validation
  if (!username || !password || !confirmPassword || !role || !validity) {
    return res.status(400).json({
      success: false,
      message: 'Semua kolom formulir (Username, Password, Konfirmasi Password, Role, Masa Aktif) wajib diisi.'
    });
  }

  if (password !== confirmPassword) {
    return res.status(400).json({
      success: false,
      message: 'Konfirmasi password tidak cocok dengan password yang dimasukkan.'
    });
  }

  if (password.length < 4) {
    return res.status(400).json({
      success: false,
      message: 'Password minimal 4 karakter.'
    });
  }

  // Validate allowed roles (Full spelling)
  const validRoles: UserRole[] = ['MEMBER', 'ADMIN', 'OWNER', 'DEVELOPER'];
  if (!validRoles.includes(role)) {
    return res.status(400).json({
      success: false,
      message: 'Pilihan role tidak valid. Pilihan harus MEMBER, ADMIN, OWNER, atau DEVELOPER.'
    });
  }

  // Validate validity duration
  const validDurations: ValidityDuration[] = ['1 HARI', '1 BULAN', 'PERMANEN'];
  if (!validDurations.includes(validity)) {
    return res.status(400).json({
      success: false,
      message: 'Pilihan masa aktif tidak valid. Pilihan harus 1 HARI, 1 BULAN, atau PERMANEN.'
    });
  }

  // Hierarchy role restrictions:
  // - ADMIN can only create MEMBER
  if (requesterRole === 'ADMIN' && role !== 'MEMBER') {
    return res.status(403).json({
      success: false,
      message: 'Akses Ditolak: Role ADMIN hanya memiliki otoritas untuk membuat akun MEMBER.'
    });
  }

  // - OWNER can create MEMBER and ADMIN, but not DEVELOPER
  if (requesterRole === 'OWNER' && role === 'DEVELOPER') {
    return res.status(403).json({
      success: false,
      message: 'Akses Ditolak: Role OWNER tidak dapat membuat akun berstatus DEVELOPER.'
    });
  }

  const cleanUser = username.trim().toLowerCase();
  const accounts = loadAccounts();

  // Duplicate username check
  if (accounts.some((u) => u.username.toLowerCase() === cleanUser)) {
    return res.status(409).json({
      success: false,
      message: `Username "${username}" sudah digunakan. Silakan gunakan username lain.`
    });
  }

  const createdAt = new Date().toISOString();
  const expiresAt = calculateExpiration(validity);
  const status: UserStatus = validity === 'PERMANEN' ? 'PERMANEN' : 'AKTIF';

  const newAccount: User = {
    id: `DRK-2026-${Math.floor(100 + Math.random() * 900)}`,
    username: username.trim(),
    displayName: (displayName || username).trim(),
    role,
    validity,
    expiresAt,
    createdAt,
    status,
    isActive: true,
    password,
    createdBy: requesterUsername,
    avatarUrl: '/drk_avatar.jpg'
  };

  accounts.push(newAccount);
  saveAccounts(accounts);

  const formattedCreated = new Date(createdAt).toLocaleString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  }) + ' WIB';

  return res.status(201).json({
    success: true,
    message: `Akun ${username} berhasil dibuat dengan role ${role}!`,
    account: {
      username: newAccount.username,
      role: newAccount.role,
      createdAt: formattedCreated,
      validity: newAccount.validity,
      expiresAt: formatExpirationDate(newAccount.expiresAt)
    }
  });
});

// Update account (Edit displayName, role, validity, status)
app.put('/api/accounts/:id', (req: Request, res: Response): any => {
  const requesterRole = req.headers['x-user-role'] as UserRole;
  if (!requesterRole || requesterRole === 'MEMBER') {
    return res.status(403).json({ success: false, message: 'Akses Ditolak: Hanya pengelola yang dapat mengubah akun.' });
  }

  const targetId = req.params.id;
  const accounts = loadAccounts();
  const index = accounts.findIndex((u) => u.id === targetId);

  if (index === -1) {
    return res.status(404).json({ success: false, message: 'Akun tidak ditemukan.' });
  }

  const target = accounts[index];

  // Protect Owner ANSEN ANTONIO from role downgrade or deactivation
  if (target.username.toLowerCase() === 'ansenantonio') {
    if (req.body.role && req.body.role !== 'DEVELOPER') {
      return res.status(403).json({ success: false, message: 'Role akun utama ANSEN ANTONIO tidak dapat diubah.' });
    }
    if (req.body.isActive === false) {
      return res.status(403).json({ success: false, message: 'Akun utama ANSEN ANTONIO tidak dapat dinonaktifkan.' });
    }
  }

  // Admin cannot modify Admin, Owner, or Developer
  if (requesterRole === 'ADMIN' && target.role !== 'MEMBER') {
    return res.status(403).json({ success: false, message: 'ADMIN hanya dapat mengelola akun dengan role MEMBER.' });
  }

  // Apply updates
  if (req.body.displayName) target.displayName = req.body.displayName;
  if (typeof req.body.isActive === 'boolean') {
    target.isActive = req.body.isActive;
    target.status = req.body.isActive ? (target.validity === 'PERMANEN' ? 'PERMANEN' : 'AKTIF') : 'NONAKTIF';
  }
  if (req.body.validity) {
    target.validity = req.body.validity;
    target.expiresAt = calculateExpiration(req.body.validity);
    if (target.isActive) {
      target.status = req.body.validity === 'PERMANEN' ? 'PERMANEN' : 'AKTIF';
    }
  }
  if (req.body.role) {
    if (requesterRole === 'DEVELOPER' || (requesterRole === 'OWNER' && req.body.role !== 'DEVELOPER')) {
      target.role = req.body.role;
    }
  }

  accounts[index] = target;
  saveAccounts(accounts);

  return res.json({
    success: true,
    message: `Akun ${target.username} berhasil diperbarui.`,
    account: target
  });
});

// Delete account
app.delete('/api/accounts/:id', (req: Request, res: Response): any => {
  const requesterRole = req.headers['x-user-role'] as UserRole;
  if (!requesterRole || requesterRole === 'MEMBER') {
    return res.status(403).json({ success: false, message: 'Akses Ditolak: Anda tidak memiliki izin untuk menghapus akun.' });
  }

  const targetId = req.params.id;
  const accounts = loadAccounts();
  const target = accounts.find((u) => u.id === targetId);

  if (!target) {
    return res.status(404).json({ success: false, message: 'Akun tidak ditemukan.' });
  }

  // PROTECT OWNER/DEVELOPER ANSEN ANTONIO
  if (target.username.toLowerCase() === 'ansenantonio') {
    return res.status(403).json({
      success: false,
      message: 'Perlindungan Sistem: Akun pemilik & developer ANSEN ANTONIO (PERMANEN) tidak dapat dihapus!'
    });
  }

  // ADMIN cannot delete ADMIN, OWNER, or DEVELOPER
  if (requesterRole === 'ADMIN' && target.role !== 'MEMBER') {
    return res.status(403).json({
      success: false,
      message: 'ADMIN hanya berhak menghapus akun MEMBER.'
    });
  }

  const filtered = accounts.filter((u) => u.id !== targetId);
  saveAccounts(filtered);

  return res.json({
    success: true,
    message: `Akun ${target.username} berhasil dihapus dari sistem.`
  });
});

// Start server with Vite middleware integration
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[DRK XXVII Engine] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start DRK XXVII server:', err);
});
